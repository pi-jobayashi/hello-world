<?php
/*
  Template name: Current Openings
*/

// Advanced Custom Fields vars
// Header
$openings_header_subline    = get_field('openings_header_subline');
$openings_header_headline   = get_field('openings_header_headline');

get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="current-openings">



    <!-- Header -->
    <header class="header current-openings-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline"><?php echo $openings_header_subline ?></div>
            <h1 class="headline"><?php echo $openings_header_headline ?></h1>
          </div>
        </div>
      </div>
    </header>




    <!-- Main Content -->
    <div class="current-openings-wrap main">


      <!-- First Section -->
      <section class="current-openings-content">
        <div class="container">
          <!-- Filter nav row -->
          <div class="row">
            <div class="col-1 col-md-1"></div>
            <div class="col-11 col-md-10 info-block col-filter-nav">
              <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md">
                  <div class="filter-nav-wrap">
                    <ul class="filter-nav">
                      <li id="all-filter-link" class="is-activated">
                        ALL
                      </li>
                      <li id="studios-filter-link">
                        STUDIO
                      </li>
                      <li id="openflats-filter-link">
                        OPEN FLAT
                      </li>
                      <li id="onebedroom-filter-link">
                        1 BEDROOM
                      </li>
                      <li id="twobedrooms-filter-link">
                        2 BEDROOM
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-1"></div>
              </div>
            </div>
            <div class="col-1 hide-on-mobile"></div>
          </div>
          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Info block -->
            <div class="col-10 info-block current-openings-gallery-wrap">
              <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                  <!-- Studios thumbs -->
                  <div id="studios" class="current-openings-gallery studios-padding">
                    <h4>Studio</h4>
                    <!-- ACF Repeater - Openings Studios Listings : BEGIN -->
                    <?php if ( have_rows('openings_studios_listings') ) { ?>
                    <div class="row">
                    	<?php while( have_rows('openings_studios_listings') ): the_row();
                    		// vars
                        $link = get_sub_field('link');
                    		$image = get_sub_field('image');
                    		$number = get_sub_field('number');
                    		$sqft = get_sub_field('sqft');
                    		$price = get_sub_field('price');
                    	?>
                      <div class="col-xs-12 col-md-4">
                        <div class="current-openings-thumbs hidden">

                          <?php if ( !empty($link) ) : ?>
                          <a href="<?php echo $link['url']; ?>">
                          <?php endif; ?>

                            <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">
                            <div class="unit-details-wrap">
                              <div class="unit-details">
                                <p class="unit-name"><?php echo $number ?></p>
                                <div class="unit-size-price-wrap">
                                  <p class="unit-size"><?php echo $sqft ?></p>
                                  <p class="unit-price"><?php echo $price ?></p>
                                </div>
                              </div>
                            </div>

                          <?php if ( !empty($link) ) : ?>
                          </a>
                          <?php endif; ?>

                        </div>
                      </div>
                      <?php endwhile; ?>
                    </div>

                    <!-- ADD IF LOGIC FOR NO STUDIO THUMB -->
                    <?php } else { ?>
                      <div class="row">
                        <div class="col">
                          <div class="info-block-actions">
                            <div class="main-button disabled">NO AVAILABLE OPENINGS</div>
                          </div>
                        </div>
                      </div>

                    <?php } ?>
                    <!-- ACF Repeater - Openings Studios Listings : END -->
                  </div>
                  <!-- Studios thumbs: END -->

                  <!-- Open flats thumbs -->
                  <div id="openflats" class="current-openings-gallery">
                    <h4>Open Flat</h4>
                    <!-- ACF Repeater - Openings Openflats Listings : BEGIN -->
                    <?php if( have_rows('openings_openflats_listings') ): ?>
                    <div class="row">
                    	<?php while( have_rows('openings_openflats_listings') ): the_row();
                    		// vars
                        $link = get_sub_field('link');
                    		$image = get_sub_field('image');
                    		$number = get_sub_field('number');
                    		$sqft = get_sub_field('sqft');
                    		$price = get_sub_field('price');
                    	?>
                      <div class="col-xs-12 col-md-4">
                        <div class="current-openings-thumbs hidden">

                          <?php if ( !empty($link) ) : ?>
                          <a href="<?php echo $link['url']; ?>">
                          <?php endif; ?>
                            <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">
                            <div class="unit-details-wrap">
                              <div class="unit-details">
                                <p class="unit-name"><?php echo $number ?></p>
                                <div class="unit-size-price-wrap">
                                  <p class="unit-size"><?php echo $sqft ?></p>
                                  <p class="unit-price"><?php echo $price ?></p>
                                </div>
                              </div>
                            </div>
                          <?php if ( !empty($link) ) : ?>
                          </a>
                          <?php endif; ?>
                        </div>
                      </div>
                      <?php endwhile; ?>
                    </div>
                    <?php endif; ?>
                    <!-- ACF Repeater - Openings Openflats Listings : END -->
                  </div>


                  <!-- One bedrooms -->
                  <div id="onebedroom" class="current-openings-gallery">
                    <h4>One Bedroom</h4>
                    <!-- ACF Repeater - Openings One Bedroom Listings : BEGIN -->
                    <?php if( have_rows('openings_onebedroom_listings') ): ?>
                    <div class="row">
                    	<?php while( have_rows('openings_onebedroom_listings') ): the_row();
                    		// vars
                        $link = get_sub_field('onebedroom_link');
                    		$image = get_sub_field('onebedroom_image');
                    		$number = get_sub_field('onebedroom_number');
                    		$sqft = get_sub_field('onebedroom_sqft');
                    		$price = get_sub_field('onebedroom_price');
                    	?>
                      <div class="col-xs-12 col-md-4">
                        <div class="current-openings-thumbs hidden">

                          <?php if ( !empty($link) ) : ?>
                          <a href="<?php echo $link['url']; ?>">
                          <?php endif; ?>
                            <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">
                            <div class="unit-details-wrap">
                              <div class="unit-details">
                                <p class="unit-name"><?php echo $number ?></p>
                                <div class="unit-size-price-wrap">
                                  <p class="unit-size"><?php echo $sqft ?></p>
                                  <p class="unit-price"><?php echo $price ?></p>
                                </div>
                              </div>
                            </div>
                          <?php if ( !empty($link) ) : ?>
                          </a>
                          <?php endif; ?>
                        </div>
                      </div>
                      <?php endwhile; ?>
                    </div>
                    <?php endif; ?>
                    <!-- ACF Repeater - Openings One Bedroom Listings : END -->

                  </div>


                  <!-- Two bedrooms -->
                  <div id="twobedrooms" class="current-openings-gallery">
                    <h4>Two Bedroom</h4>
                    <!-- ACF Repeater - Openings Two Bedrooms Listings : BEGIN -->
                    <?php if( have_rows('openings_twobedrooms_listings') ): ?>
                    <div class="row">
                      <?php while( have_rows('openings_twobedrooms_listings') ): the_row();
                        // vars
                        $link = get_sub_field('link');
                        $image = get_sub_field('image');
                        $number = get_sub_field('number');
                        $sqft = get_sub_field('sqft');
                        $price = get_sub_field('price');
                      ?>
                      <div class="col-xs-12 col-md-4">
                        <div class="current-openings-thumbs hidden">

                          <?php if ( !empty($link) ) : ?>
                          <a href="<?php echo $link['url']; ?>">
                          <?php endif; ?>
                            <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">
                            <div class="unit-details-wrap">
                              <div class="unit-details">
                                <p class="unit-name"><?php echo $number ?></p>
                                <div class="unit-size-price-wrap">
                                  <p class="unit-size"><?php echo $sqft ?></p>
                                  <p class="unit-price"><?php echo $price ?></p>
                                </div>
                              </div>
                            </div>
                          <?php if ( !empty($link) ) : ?>
                          </a>
                          <?php endif; ?>
                        </div>
                      </div>
                      <?php endwhile; ?>
                    </div>
                    <?php endif; ?>
                    <!-- ACF Repeater - Openings Two Bedrooms Listings : END -->
                  </div>
                </div>
                <div class="col-md-1"></div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
          <!-- Second row -->
        </div>
      </section>

      <!-- Footer wuz here!!! -->

    </div>

  </div>
</div>


<?php
get_footer();
