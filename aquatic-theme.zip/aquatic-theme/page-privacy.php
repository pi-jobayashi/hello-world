<?php
/*
  Template name: Privacy Policy
*/

// Advanced Custom Fields vars
// header
$privacy_header_subline   = get_field('privacy_header_subline');
$privacy_header_headline  = get_field('privacy_header_headline');
// Content
$privacy_section_headline = get_field('privacy_section_headline');
$privacy_section_headline_desc = get_field('privacy_section_headline_desc');
$privacy_section_img      = get_field('privacy_section_img');
$privacy_section_desc     = get_field('privacy_section_desc');

get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="privacy">



    <!-- Header -->
    <header class="header privacy-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline"><?php echo $privacy_header_subline; ?></div>
            <h1 class="headline"><?php echo $privacy_header_headline; ?></h1>
          </div>
        </div>
      </div>
    </header>


    <!-- Main Content -->
    <div class="privacy-content main">


      <!-- First Section -->
      <section class="privacy-details">
        <div class="container">
          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Content -->
            <div class="col-1 info-block"></div>
            <div class="col info-block">
              <div class="row">
                <div class="col-5">
                  <h2 class="headline"><?php echo $privacy_section_headline; ?></h2>
                  <div><?php echo $privacy_section_headline_desc; ?></div>
                </div>
                <div class="col-7">
                </div>
              </div>
              <div class="row privacy-image-details">
                <div class="col-5">
                  <?php if ( $privacy_section_img ) : ?>
                    <img src="<?php echo $privacy_section_img['url']; ?>" alt="<?php echo $privacy_section_img['alt']; ?>">
                  <?php endif; ?>
                </div>
                <div class="col-7">
                  <?php if ( $privacy_section_desc ) : ?>
                  <div>
                    <?php echo $privacy_section_desc ?>
                  </div>
                  <?php endif; ?>
                </div>
              </div>
              <!-- Privacy Footer -->
              <div class="row privacy-footer-row">
                <div class="col footer-info">
                  <div class="aquatic-bar-logo top-footer-links">
                    <div>
                      <img src="<?php bloginfo('stylesheet_directory'); ?>/images/AQUATIC-logo-footer.svg" alt="Aquatic Logo for footer">
                    </div>
                  </div>
                  <div class="top-footer-links">
                    <p>2010 Fifth St.</p>
                    <p>Berkeley, CA 94710</p>
                  </div>
                  <div class="top-footer-links">
                    <p>T: <a href="tel:8559794663">855-979-HOME</a></p>
                    <p>T: <a href="tel:5102502404">510-250-2404</a></p>
                  </div>
                  <div class="top-footer-links">
                    <p>Email:</p>
                    <p><a href="mailto:management@aquaticliving.com">management@aquaticliving.com</a></p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1 info-block"></div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
        </div>
      </section>


    </div>

  </div>
</div>


<?php
get_footer();
