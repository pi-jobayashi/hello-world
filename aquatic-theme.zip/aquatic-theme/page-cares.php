<?php
/*
  Template name: Cares
*/

// Advanced Custom Fields vars
// Header
$cares_header_headline          = get_field('cares_header_headline');
// Fourth Street Section
$cares_environmental_subline    = get_field('cares_environmental_subline');
$cares_environmental_headline   = get_field('cares_environmental_headline');
$cares_environmental_list_1     = get_field('cares_environmental_list_1');
$cares_environmental_list_2     = get_field('cares_environmental_list_2');
// Fourth Street Section
$cares_community_subline        = get_field('cares_community_subline');
$cares_community_headline       = get_field('cares_community_headline');
$cares_community_list_1         = get_field('cares_community_list_1');


get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="cares">



    <!-- Header -->
    <header class="header cares-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <h1 class="headline white"><?php echo $cares_header_headline ?></h1>
          </div>
        </div>
      </div>
    </header>



    <!-- Main Content -->
    <div class="cares-content main">



      <!-- First Section -->
      <section class="cares-section environmental-care">
        <div class="container">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Cares content here -->
            <div class="col-10 cares-details">
              <div class="row">
                <div class="col-md-1"></div>
                <div class="col col-md-10 info-block">
                  <div class="subline"><?php echo $cares_environmental_subline ?></div>
                  <h4 class="headline-italic delay-1"><?php echo $cares_environmental_headline?></h4>
                </div>
                <div class="col-md-1"></div>
              </div>
              <div class="row">
                <div class="col-1"></div>
                <div class="col-md-5 info-block list left hidden delay-2">
                  <?php echo $cares_environmental_list_1 ?>
                </div>
                <div class="col-md-5 info-block list right hidden delay-3">
                  <?php echo $cares_environmental_list_2 ?>
                </div>
                <div class="col-1"></div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
        </div>
      </section>


      <!-- First Slider -->
      <section class="cares-section slider-wrap-1">
        <div class="container">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
            <div class="col-md-1 info-block"></div>
            <!-- Slick Slider 1 : BEGIN -->
            <div class="col-md-8 no-mobile-slider-padding">
              <div class="praise-quotes-slider-wrap">
                <div class="slider-bg-to-scale-up scaled-orig-size"></div>
                <?php if( have_rows('cares_slider_1') ): ?>
                <div class="praise-quotes-slider cares-page-slick-slider-1">
              	<?php while( have_rows('cares_slider_1') ): the_row();
              		// vars
              		$quote  = get_sub_field('cares_slider_quote_text');
              		$source = get_sub_field('cares_slider_quote_source');
              		$title  = get_sub_field('cares_slider_quote_source_title');
              	?>
              		<div class="praise-slide">
                    <!-- <img src="<?php bloginfo('stylesheet_directory'); ?>/images/praise-quotes-bg.png" alt=""> -->
                    <div class="praise-slide-text-block">
                      <div class="praise-quotation-marks">
                        <img src="<?php bloginfo('stylesheet_directory'); ?>/images/praise-quotation-marks.svg" alt="" />
                      </div>
                      <h3><?php echo $quote ?></h3>
                      <p class="praise-person-name"><?php echo $source ?></p>
                      <p class="praise-person-title"><?php echo $title ?></p>
                    </div>
              		</div>
              	<?php endwhile; ?>
                </div>
                <?php endif; ?>
              </div>
            </div>
            <!-- Slick Slider 1 : END -->
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
            <div class="col-md-1"></div>
          </div>
        </div>
      </section>



      <!-- Second Section -->
      <section class="cares-section full-width-photos">
        <div class="container">
          <div class="row">
            <!-- Location content here -->
            <div class="col-xs-12 col-sm no-gutters half-width-photo slidey-slide-uppy-up">
              <img src="<?php bloginfo('stylesheet_directory'); ?>/images/full-width-gallery-photo-1-compressed.jpg" alt="">
            </div>
            <div class="col-xs-12 col-sm no-gutters half-width-photo slidey-slide-uppy-up">
              <img src="<?php bloginfo('stylesheet_directory'); ?>/images/full-width-gallery-photo-2-compressed.jpg" alt="">
            </div>
          </div>
        </div>
      </section>





      <!-- Third Section -->
      <section class="cares-section the-community">
        <div class="container">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Cares content here -->
            <div class="col-10 cares-details">
              <div class="row">
                <div class="col-md-1"></div>
                <div class="col col-md-10 info-block">
                  <div class="subline hidden"><?php echo $cares_community_subline ?></div>
                  <h4 class="headline-italic hidden delay-1"><?php echo $cares_community_headline?></h4>
                </div>
                <div class="col-md-1"></div>
              </div>
              <div class="row">
                <div class="col-1"></div>
                <div class="col-md-5 info-block list-column list left hidden delay-2">
                  <?php echo $cares_community_list_1 ?>
                </div>
                <div class="col-md-5 info-block photo-column list right hidden delay-3">
                  <img src="<?php bloginfo('stylesheet_directory'); ?>/images/cares-square-thumb-1-compressed.jpg" alt="">
                </div>
                <div class="col-1"></div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
        </div>
      </section>


      <!-- First Slider -->
      <section class="cares-section slider-wrap-2">
        <div class="container">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
            <div class="col-md-1 info-block"></div>



            <!-- Slick Slider 2 : BEGIN -->
            <div class="col-md-8 no-mobile-slider-padding">
              <div class="praise-quotes-slider-wrap">
                <div class="slider-bg-to-scale-up-2 scaled-orig-size"></div>
                <?php if( have_rows('cares_slider_2') ): ?>
                <div class="praise-quotes-slider cares-page-slick-slider-2">
              	<?php while( have_rows('cares_slider_2') ): the_row();
              		// vars
              		$quote  = get_sub_field('cares_slider_quote_text');
              		$source = get_sub_field('cares_slider_quote_source');
              		$title  = get_sub_field('cares_slider_quote_source_title');
              	?>
              		<div class="praise-slide">
                    <!-- <img src="<?php bloginfo('stylesheet_directory'); ?>/images/praise-quotes-bg.png" alt=""> -->
                    <div class="praise-slide-text-block">
                      <div class="praise-quotation-marks">
                        <img src="<?php bloginfo('stylesheet_directory'); ?>/images/praise-quotation-marks.svg" alt="" />
                      </div>
                      <h3><?php echo $quote ?></h3>
                      <p class="praise-person-name"><?php echo $source ?></p>
                      <p class="praise-person-title"><?php echo $title ?></p>
                    </div>
              		</div>
              	<?php endwhile; ?>
                </div>
                <?php endif; ?>
                <!-- <div class="praise-quotes-slider-frame-1">
                  <img src="<?php bloginfo('stylesheet_directory'); ?>/images/praise-quotes-frame-1.png" alt="">
                </div> -->
              </div>
            </div>
            <!-- Slick Slider 2 : END -->

            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
            <div class="col-md-1"></div>
          </div>
        </div>
      </section>



      <!-- Fixed footer - apply for this unit -->
      <a class="fixed-footer-cta-mobile" href="/current-openings">
        <span>&gt;</span> VIEW UNITS
      </a>


      <!-- Footer wuz here!!! -->



    </div>

  </div>
</div>


<?php
get_footer();
