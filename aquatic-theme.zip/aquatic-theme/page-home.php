<?php
/*
  Template name: Homepage
*/

// Advanced Custom Fields vars
// Stencil A Section
$stencil_a_subline   = get_field('stencil_a_subline');
$stencil_a_headline  = get_field('stencil_a_headline');
$stencil_a_desc      = get_field('stencil_a_desc');
$stencil_a_button    = get_field('stencil_a_button');
// Photo Gallery Section
$photo_gallery_subline   = get_field('photo_gallery_subline');
$photo_gallery_headline  = get_field('photo_gallery_headline');
$photo_gallery_button    = get_field('photo_gallery_button');
$photo_gallery_text_link = get_field('photo_gallery_text_link');
// Sticky Note Section
$sticky_note_subline   = get_field('sticky_note_subline');
$sticky_note_headline  = get_field('sticky_note_headline');
$sticky_note_desc      = get_field('sticky_note_desc');
$sticky_note_button    = get_field('sticky_note_button');
// Nice Doggie Section
$nice_doggie_subline   = get_field('nice_doggie_subline');
$nice_doggie_headline  = get_field('nice_doggie_headline');
$nice_doggie_desc      = get_field('nice_doggie_desc');
$nice_doggie_list_1    = get_field('nice_doggie_list_1');
$nice_doggie_list_2    = get_field('nice_doggie_list_2');
$nice_doggie_button    = get_field('nice_doggie_button');

get_header();
?>



<!-- Preloader -->
<div id="preloader">
  <div class="loader-screen-bg-color"></div>
  <div class="loader-logo-wrap">
    <img id="preloader-logo" src="<?php bloginfo('stylesheet_directory'); ?>/images/aquatic-logo.svg" alt="Aquatic Logo">
  </div>
</div>




<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="homepage">



    <!-- Video Header -->
    <header class="header logo-header video-header">
      <div class="fullscreen-video-wrap">
        <!-- For video -->
        <video poster="<?php bloginfo('stylesheet_directory'); ?>/images/aquatic-sizzle-hero-poster.jpg" autoplay loop muted preload playsinline>
           <source src="<?php bloginfo('stylesheet_directory'); ?>/videos/aquatic-hero-sizzle-reel.mp4" type="video/mp4">
        </video>
      </div>
      <div id="homepage-logo-container" class="container">
        <div class="loader-logo-wrap">
          <img id="homepage-logo" src="<?php bloginfo('stylesheet_directory'); ?>/images/aquatic-logo-white.svg" alt="Aquatic Logo">
        </div>
      </div>
    </header>



    <!-- Main Content -->
    <div class="homepage-content main">



      <!-- First Section -->
      <section class="letter-stencil">
        <div class="container">

          <!-- special xl-desktop white-bg column -->
          <div class="col-fix-for-xl-desktop"></div>

          <!-- main row -->
          <div class="row">

            <div class="col-md-1 info-block"></div>

            <div class="col-md-10 no-padding-ie-fix">

              <div id="stencil-row" class="row">
                <div class="col-md-6 info-block text-block order-class">
                  <div class="subline hidden"><?php echo $stencil_a_subline ?></div>
                  <h2 class="headline hidden delay-1"><?php echo $stencil_a_headline ?></h2>
                  <p class="hidden delay-2"><?php echo $stencil_a_desc ?></p>
                  <div class="info-block-actions">
                    <?php if ( !empty($stencil_a_button) ) : ?>
                    <a class="hidden delay-3" href="<?php echo $stencil_a_button['url']; ?>">
                      <div class="main-button">
                        <?php echo $stencil_a_button['title']; ?>
                      </div>
                    </a>
                    <?php endif; ?>
                  </div>
                </div>
                <!-- A Stencil -->
                <div id="a-stencil" class="col-md-6 order-class">
                  <img src="<?php bloginfo('stylesheet_directory'); ?>/images/a-stencil.svg" alt="Aquatic A stencil">
                </div>
              </div>

            </div>

            <div class="col-md-1 info-block left-margin-adjust"></div>

          </div>

          <!-- special xl-desktop white-bg column -->
          <div class="col-fix-for-xl-desktop"></div>

        </div>
      </section>



      <!-- Second Section -->
      <section class="photo-gallery">
        <div class="container">
          <div class="row photo-gallery-row first-row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
            <div class="col info-block">
              <div class="row">
                <!-- Info block -->
                <div class="col-md-6 info-block text-block no-bottom-padding">
                  <div class="subline hidden"><?php echo $photo_gallery_subline ?></div>
                  <h2 class="headline hidden delay-1"><?php echo $photo_gallery_headline ?></h2>
                </div>
              </div>
              <div class="row no-mobile-gutters">
                <!-- <div class="col-md-5 no-gutters"> -->
                <div class="col-md-5">
                  <div class="info-block-location-links">
                    <ul class="location-list">
                      <li class="is-active hidden">
                        <strong>Aquatic Fourth Street</strong> <span class="dark-hyphen">-</span> West Berkeley
                      </li>
                      <li class="hidden delay-1">
                        <strong>Aquatic Shattuck</strong> <span class="dark-hyphen">-</span> Downtown Berkeley <span class="dark-hyphen">-</span><span class="coming-soon-span"> coming soon</span>
                      </li>
                      <li class="hidden delay-2">
                        <strong>Aquatic Gilman</strong> <span class="dark-hyphen">-</span> North Berkeley <span class="dark-hyphen">-</span><span class="coming-soon-span"> coming soon</span>
                      </li>
                    </ul>
                    <!-- Mobile gallery here -->
                    <div class="homepage-mobile-slider hidden delay-2">
                      <div class="item video">
                        <video autoplay loop muted preload playsinline>
                          <source src="<?php bloginfo('stylesheet_directory'); ?>/videos/many-cultures-many-places-2x1.mp4" type="video/mp4">
                        </video>
                      </div>
                      <div class="item image">
                        <img src="<?php bloginfo('stylesheet_directory'); ?>/images/homepage-square-thumb-2-compressed.jpg" alt="Square Thumb">
                      </div>
                      <div class="item image">
                        <img src="<?php bloginfo('stylesheet_directory'); ?>/images/homepage-square-thumb-3-compressed.jpg" alt="Square Thumb">
                      </div>
                      <div class="item image">
                        <img src="<?php bloginfo('stylesheet_directory'); ?>/images/homepage-square-thumb-4-compressed.jpg" alt="Square Thumb">
                      </div>
                    </div>
                    <div class="stamp-for-mobile">
                      <img src="<?php bloginfo('stylesheet_directory'); ?>/images/location-stamp-fourth-street.png" alt="Fourth Street District stamp for Aquatic Living">
                    </div>
                    <div class="info-block-actions">
                      <?php if ( !empty($photo_gallery_button) ) : ?>
                      <a class="hidden delay-2" href="<?php echo $photo_gallery_button['url']; ?>">
                        <div class="main-button">
                          <?php echo $photo_gallery_button['title']; ?>
                        </div>
                      </a>
                      <?php endif; ?>
                      <div class="text-link hidden delay-3">
                        <?php if ( !empty($photo_gallery_text_link) ) : ?>
                        <a href="<?php echo $photo_gallery_text_link['url']; ?>">
                          <?php echo $photo_gallery_text_link['title']; ?>
                        </a>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Spacer -->
                <div class="col-md-7"></div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
          </div>
          <!-- Photo Gallery - Custom Grid - Square Thumbs -->
          <div class="row photo-gallery-row second-row">
            <div class="col-md-2 info-block"></div>
            <div class="col-md-9 info-block">

              <!-- ie11 row height fix : BEGIN -->
              <div class="container">

                <!-- first row of square thumbs -->
                <div class="row row-relative-position">
                  <div class="col-md-4 negative-margin-fix"></div>
                  <div class="col-md-8 no-gutters-homepage hidden">
                    <video autoplay loop muted preload playsinline>
                      <source src="<?php bloginfo('stylesheet_directory'); ?>/videos/many-cultures-many-places-2x1.mp4" type="video/mp4">
                    </video>
                  </div>
                </div>

                <!-- second row of square thumbs -->
                <div class="row row-relative-position">
                  <div class="col no-gutters-homepage">
                    <img class="hidden delay-1" src="<?php bloginfo('stylesheet_directory'); ?>/images/homepage-square-thumb-2-compressed.jpg" alt="Square Thumb">
                  </div>
                  <div class="col no-gutters-homepage">
                    <img class="hidden delay-2" src="<?php bloginfo('stylesheet_directory'); ?>/images/homepage-square-thumb-3-compressed.jpg" alt="Square Thumb">
                  </div>
                  <div class="col no-gutters-homepage">
                    <img class="hidden delay-3" src="<?php bloginfo('stylesheet_directory'); ?>/images/homepage-square-thumb-4-compressed.jpg" alt="Square Thumb">
                  </div>
                </div>

                <!-- stamp -->
                <div class="stamp hidden delay-4">
                  <img src="<?php bloginfo('stylesheet_directory'); ?>/images/location-stamp-fourth-street.png" alt="Fourth Street District stamp for Aquatic Living">
                </div>

              </div>
              <!-- ie11 row height fix : END -->



            </div>
            <div class="col-md-1 info-block"></div>
          </div>
        </div>
      </section>



      <!-- Third Section -->
      <section class="sticky-note">
        <div class="container">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
            <!-- Sticky note -->
            <div id="a-sticky-note" class="col-md-5 hidden">
              <img src="<?php bloginfo('stylesheet_directory'); ?>/images/a-sticky-note-compressed.jpg" alt="A big Aquatic A with sticky notes">
            </div>
            <!-- Info block -->
            <div class="col-md-5 info-block text-block">
              <div class="subline hidden"><?php echo $sticky_note_subline ?></div>
              <h2 class="headline hidden delay-1"><?php echo $sticky_note_headline ?></h2>
              <p class="hidden delay-2"><?php echo $sticky_note_desc ?></p>
              <div class="hidden" id="a-sticky-note-mobile">
                <img src="<?php bloginfo('stylesheet_directory'); ?>/images/a-sticky-note-compressed.jpg" alt="A big Aquatic A with sticky notes">
              </div>
              <div class="info-block-actions">
                <?php if ( !empty($sticky_note_button) ) : ?>
                <a class="hidden delay-2" href="<?php echo $sticky_note_button['url']; ?>">
                  <div class="main-button">
                    <?php echo $sticky_note_button['title']; ?>
                  </div>
                </a>
                <?php endif; ?>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
          </div>
        </div>
      </section>



      <!-- Fourth Section -->
      <section class="worth-it">
        <div class="container">
          <div class="row image-bg doggie-bg">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
            <!-- Info block -->
            <div class="col-md-7 col-lg-6 info-block text-block">
              <div class="subline hidden delay-1"><?php echo $nice_doggie_subline ?></div>
              <h2 class="headline hidden delay-2"><?php echo $nice_doggie_headline ?></h2>
              <p class="hidden delay-3">
                <?php echo $nice_doggie_desc ?>
              </p>
              <div class="container amenities-list">
                <div class="row">
                  <div class="col-md-6 hidden delay-3">
                    <?php echo $nice_doggie_list_1 ?>
                  </div>
                  <div class="col-md-6 hidden delay-3">
                    <?php echo $nice_doggie_list_2 ?>
                  </div>
                </div>
              </div>
              <div class="info-block-actions">
                <?php if ( !empty($nice_doggie_button) ) : ?>
                <a class="hidden delay-3" href="<?php echo $nice_doggie_button['url']; ?>">
                  <div class="main-button">
                    <?php echo $nice_doggie_button['title']; ?>
                  </div>
                </a>
                <?php endif; ?>
              </div>
            </div>
            <!-- Spacer, to fill remaining main info block area -->
            <div class="col-md-3 col-lg-4 info-block"></div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
          </div>
        </div>
      </section>

      <div class="doggie-prefooter">
        <img src="<?php bloginfo('stylesheet_directory'); ?>/images/Dog-image-compressed.jpg" alt="">
      </div>



      <!-- Fixed footer - apply for this unit -->
      <a class="fixed-footer-cta-mobile" href="/current-openings">
        <span>&gt;</span> VIEW UNITS
      </a>



      <!-- Footer wuz here!!! -->

    </div>

  </div>
</div>


<?php
get_footer();
