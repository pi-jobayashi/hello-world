<?php
/**
	* The template for displaying the footer
	*
	* Contains the closing of the #content div and all content after.
	*
	* @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
	*
	* @package Aquatic
*/

// Advanced Custom Fields vars
?>

	<!-- </div> -->
	<!-- #content -->

	<!-- Custom footer -->
	<footer>
		<div class="container">
			<div class="row footer-info">
				<div class="aquatic-bar-logo top-footer-links">
					<div>
						<img src="<?php bloginfo('stylesheet_directory'); ?>/images/AQUATIC-logo-footer.svg" alt="Aquatic Logo for footer">
					</div>
				</div>
				<div class="top-footer-links">
					<a href="https://www.google.com/maps/place/The+Aquatic/@37.867057,-122.298602,15z/data=!4m5!3m4!1s0x0:0xe0a46af2d808ce1!8m2!3d37.867057!4d-122.298602?hl=en-US" target="_blank">
						<p>2010 Fifth St.</p>
						<p>Berkeley, CA 94710</p>
					</a>
				</div>
				<div class="top-footer-links">
					<p>T: <a href="tel:8559794663">855-979-HOME</a></p>
					<p>T: <a href="tel:5102502404">510-250-2404</a></p>
				</div>
				<div class="top-footer-links">
					<p>Email:</p>
					<p><a href="mailto:management@aquaticliving.com">management@aquaticliving.com</a></p>
				</div>
				<div class="eho-logo top-footer-links">
					<img src="<?php bloginfo('stylesheet_directory'); ?>/images/equal-opportunity-housing-logo.svg" alt="equal-opportunity-housing-logo">
				</div>
			</div>
			<div class="row footer-social">
				<div class="social-logos">
					<a href="https://slack.com/signin" target="_blank">
						<div class="social-logo slack">
							<img src="<?php bloginfo('stylesheet_directory'); ?>/images/slack-logo-for-aquatic-compressed.jpg" alt="slack-logo-for-aquatic">
							<strong>Residents</strong><span class="show-on-desktop">&nbsp;-&nbsp;</span>
						</div>
						<div class="slack-text">
							Need a cup of sugar? Looking for a scuba partner? Join our private Slack Channel to get to know thy neighbor.
						</div>
					</a>
				</div>
				<div class="social-logos">
					<div class="social-logo">
						<a href="https://www.instagram.com/aquaticliving" target="_blank">
							<img src="<?php bloginfo('stylesheet_directory'); ?>/images/instagram-logo-for-aquatic.svg" alt="instagram-logo-for-aquatic">
						</a>
					</div>
					<div class="social-logo">
						<a href="https://www.yelp.com/biz/the-aquatic-berkeley" target="_blank">
							<img src="<?php bloginfo('stylesheet_directory'); ?>/images/yelp-logo-for-aquatic.svg" alt="yelp-logo-for-aquatic">
						</a>
					</div>
					<div class="social-logo">
						<a href="https://twitter.com/LiveAquaticNow" target="_blank">
							<img src="<?php bloginfo('stylesheet_directory'); ?>/images/twitter-logo-for-aquatic.svg" alt="twitter-logo-for-aquatic">
						</a>
					</div>
					<div class="social-logo">
						<a class="no-barba" href="https://www.google.com/maps/place/The+Aquatic/@37.867057,-122.298602,15z/data=!4m5!3m4!1s0x0:0xe0a46af2d808ce1!8m2!3d37.867057!4d-122.298602?hl=en-US" target="_blank">
							<img src="<?php bloginfo('stylesheet_directory'); ?>/images/google-logo-for-aquatic.svg" alt="google-logo-for-aquatic">
						</a>
					</div>
				</div>
			</div>
			<div class="row footer-legal">
				<div class="break-on-mobile">
					&copy; The Aquatic Residences, 2018
				</div>
				<div>
					<a href="/privacy-policy">
						Privacy Policy
					</a>
				</div>
				<div>
					<a href="https://makersandallies.com/" target="_blank">
						Made by Makers
					</a>
				</div>
			</div>
		</div>
	</footer>



	<!-- Nav overlay -->
	<div class="nav-overlay">
		<div class="nav-overlay-bg-replace-living"></div>
		<div class="nav-overlay-bg-replace-locations"></div>
		<div class="nav-overlay-bg-replace-cares"></div>
		<div class="nav-overlay-bg-replace-tenants"></div>
		<div class="nav-overlay-bg-replace-contact"></div>

		<div class="container nav-overlay-wrap">
			<!-- Top row -->
			<div class="row">
				<div class="col nav-overlay-col-ie-width-fix">
					<a class="hidden-nav" href="<?php echo get_permalink(44) ?>">
						<h5>AMENITIES &amp; CULTURE</h5>
						<h3>Life at Aquatic</h3>
					</a>
					<a class="hidden-nav delay-1" href="<?php echo get_permalink(47) ?>">
						<h5>FIND YOUR HOME</h5>
						<h3>Our Locations</h3>
					</a>
					<a class="hidden-nav delay-2" href="<?php echo get_permalink(49) ?>">
						<h5>COMMUNITY LOVE</h5>
						<h3>Aquatic Cares</h3>
					</a>
				</div>
			</div>
			<!-- Second row -->
			<div class="row">
				<div class="col nav-overlay-col-ie-width-fix">
					<a class="hidden-nav delay-3 order-class" href="<?php echo get_permalink(51) ?>">
						<p>Tenant Portal</p>
					</a>
					<a class="hidden-nav delay-3 order-class" href="<?php echo get_permalink(53) ?>">
						<p>Contact Aquatic</p>
					</a>
				</div>
			</div>
		</div>
	</div>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
