<?php
/*
  Template name: Neighborhood
*/

// Advanced Custom Fields vars
// Header
$neighborhood_header_subline    = get_field('neighborhood_header_subline');
$neighborhood_header_headline   = get_field('neighborhood_header_headline');
// At A Glance Section
$neighborhood_details_image     = get_field('neighborhood_details_image');
$neighborhood_details_headline  = get_field('neighborhood_details_headline');
$neighborhood_details_desc      = get_field('neighborhood_details_desc');
// Map
$neighborhood_map_image         = get_field('neighborhood_map_image');
// Social Links
$neighborhood_eat_links         = get_field('neighborhood_eat_links');
$neighborhood_cafe_links        = get_field('neighborhood_cafe_links');
$neighborhood_bar_links         = get_field('neighborhood_bar_links');
$neighborhood_shop_links        = get_field('neighborhood_shop_links');
// Slider Section
$neighborhood_slider_headline   = get_field('neighborhood_slider_headline');
$neighborhood_slider_desc       = get_field('neighborhood_slider_desc');
// Check Available
$neighborhood_check_button      = get_field('neighborhood_check_button');

get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="neighborhood">



    <!-- Header -->
    <header class="header neighborhood-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline"><?php echo $neighborhood_header_subline ?></div>
            <h1 class="headline"><?php echo $neighborhood_header_headline ?></h1>
          </div>
        </div>
      </div>
    </header>



    <!-- Map Image Overlay -->
    <div id="#map-overlay" class="image-overlay">
      <div class="image-overlay-inner">
        <?php if ( !empty($neighborhood_map_image) ) : ?>
          <img src="<?php echo $neighborhood_map_image['url']; ?>" alt="<?php echo $neighborhood_map_image['alt']; ?>">
        <?php endif; ?>
      </div>
      <button class="image-overlay-close"></button>
    </div>



    <!-- Main Content -->
    <div class="neighborhood-content-wrap main">

      <!-- First Section -->
      <section class="neighborhood-at-a-glance">
        <div class="container">
          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Info block -->
            <div class="col-10 info-block negative-top-margin-mobile">
              <!-- Photo and title -->
              <div class="row">
                <!-- <div class="col-md-1"></div> -->
                <div class="col-md-6 neighborhood-featured-photo hide-photo-on-mobile">
                  <?php if ( !empty($neighborhood_details_image) ) :?>
                    <img src="<?php echo $neighborhood_details_image['url']; ?>" alt="<?php echo $neighborhood_details_image['alt']; ?>">
                  <?php endif; ?>
                </div>
                <div class="col-md-5 info-block">
                  <!-- <div class="headline hidden"><?php echo $neighborhood_details_headline ?></div> -->
                  <div class="headline"><?php echo $neighborhood_details_headline ?></div>
                  <p class=""><?php echo $neighborhood_details_desc ?></p>
                </div>
                <div class="col-md-1"></div>
              </div>
              <!-- Three columns of stats -->
              <div class="row neighborhood-statistics-wrap">
                <!-- for spacing -->
                <!-- <div class="col-1"></div> -->

                <!-- Fun Facts : BEGIN -->
                <?php if( have_rows('fun_facts') ): ?>
                <!-- <div class="row"> -->
                <div class="col-md-1"></div>

                  <?php while( have_rows('fun_facts') ): the_row();
                    // vars
                    $headline = get_sub_field('headline');
                    $subline = get_sub_field('subline');
                  ?>
                  <div class="col-sm-12 col-md neighborhood-statistic">
                    <div class="headline hidden">
                      <?php echo $headline ?>
                    </div>
                    <div class="subline hidden delay-1">
                      <?php echo $subline ?>
                    </div>
                  </div>
                  <?php endwhile; ?>
                <div class="col-md-1"></div>
                <!-- </div> -->
                <?php endif; ?>
                <!-- Fun Facts : END -->

                <!-- for spacing -->
                <!-- <div class="col-1"></div> -->
              </div>
              <div class="row">
                <div class="col-md-1"></div>
                <div class="col-sm-12 col-md neighborhood-featured-photo show-photo-on-mobile">
                  <?php if ( !empty($neighborhood_details_image) ) :?>
                    <img src="<?php echo $neighborhood_details_image['url']; ?>" alt="<?php echo $neighborhood_details_image['alt']; ?>">
                  <?php endif; ?>
                </div>
                <div class="col-md-1"></div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
        </div>
      </section>



      <!-- Second Section -->
      <section class="neighborhood-map">
        <div class="container">
          <!-- First row -->
          <div class="row">
            <!-- full-width map -->
            <div class="col map-bg">
              <?php if ( !empty($neighborhood_map_image) ) :?>
                <img src="<?php echo $neighborhood_map_image['url']; ?>" alt="<?php echo $neighborhood_map_image['alt']; ?>">
              <?php endif; ?>
            </div>
          </div>
        </div>
      </section>



      <!-- Third Section -->
      <section class="neighborhood-social-links">
        <div class="container">
          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Info block -->
            <div class="col-10">
              <!-- Three columns of stats -->
              <div class="row neighborhood-social-links-wrap">
                <!-- for spacing -->
                <div class="col-lg-1"></div>
                <!-- First column -->
                <div class="col-xs-12 col-md-6 col-lg neighborhood-social-links-column hidden">
                  <div class="headline">
                    Eat
                  </div>
                  <!-- ACF repeater for social links -->
                  <?php if( have_rows('neighborhood_eat_links') ): ?>
                  <div class="social-links-wrap">
                    <?php while( have_rows('neighborhood_eat_links') ): the_row();
                      // vars
                      $title = get_sub_field('title');
                      $website_url = get_sub_field('website_url');
                      $social_url = get_sub_field('social_url');
                    ?>
                    <!-- link title -->
                    <div class="social-link-title">
                      <?php echo $title; ?>
                    </div>
                    <!-- link links -->
                    <div class="social-link-links">
                      <?php if ($website_url) : ?>
                      <a class="website-url" href="<?php echo $website_url['url']; ?>" target="_blank">
                      <?php endif; ?>
                        <span>&gt;</span> WEBSITE
                      <?php if ($website_url) : ?>
                      </a>
                      <?php endif; ?>
                      <?php if ($social_url) : ?>
                      <a class="social-url" href="<?php echo $social_url['url']; ?>" target="_blank">
                      <?php endif; ?>
                        SOCIAL
                      <?php if ($social_url) : ?>
                      </a>
                      <?php endif; ?>
                    </div>
                    <?php endwhile; ?>
                  </div>
                  <?php endif; ?>
                </div>
                <!-- Second column -->
                <div class="col-xs-12 col-md-6 col-lg neighborhood-social-links-column hidden delay-1">
                  <div class="headline">
                    Caf&eacute;
                  </div>
                  <!-- ACF repeater for social links -->
                  <?php if( have_rows('neighborhood_cafe_links') ): ?>
                  <div class="social-links-wrap">
                    <?php while( have_rows('neighborhood_cafe_links') ): the_row();
                      // vars
                      $title = get_sub_field('title');
                      $website_url = get_sub_field('website_url');
                      $social_url = get_sub_field('social_url');
                    ?>
                    <!-- link title -->
                    <div class="social-link-title">
                      <?php echo $title; ?>
                    </div>
                    <!-- link links -->
                    <div class="social-link-links">
                      <?php if ($website_url) : ?>
                      <a class="website-url" href="<?php echo $website_url['url']; ?>" target="_blank">
                      <?php endif; ?>
                        <span>&gt;</span> WEBSITE
                      <?php if ($website_url) : ?>
                      </a>
                      <?php endif; ?>
                      <?php if ($social_url) : ?>
                      <a class="social-url" href="<?php echo $social_url['url']; ?>" target="_blank">
                      <?php endif; ?>
                        SOCIAL
                      <?php if ($social_url) : ?>
                      </a>
                      <?php endif; ?>
                    </div>
                    <?php endwhile; ?>
                  </div>
                  <?php endif; ?>
                </div>
                <!-- Third column -->
                <div class="col-xs-12 col-md-6 col-lg neighborhood-social-links-column hidden delay-2">
                  <div class="headline">
                    Bar
                  </div>
                  <!-- ACF repeater for social links -->
                  <?php if( have_rows('neighborhood_bar_links') ): ?>
                  <div class="social-links-wrap">
                    <?php while( have_rows('neighborhood_bar_links') ): the_row();
                      // vars
                      $title = get_sub_field('title');
                      $website_url = get_sub_field('website_url');
                      $social_url = get_sub_field('social_url');
                    ?>
                    <!-- link title -->
                    <div class="social-link-title">
                      <?php echo $title; ?>
                    </div>
                    <!-- link links -->
                    <div class="social-link-links">
                      <?php if ($website_url) : ?>
                      <a class="website-url" href="<?php echo $website_url['url']; ?>" target="_blank">
                      <?php endif; ?>
                        <span>&gt;</span> WEBSITE
                      <?php if ($website_url) : ?>
                      </a>
                      <?php endif; ?>
                      <?php if ($social_url) : ?>
                      <a class="social-url" href="<?php echo $social_url['url']; ?>" target="_blank">
                      <?php endif; ?>
                        SOCIAL
                      <?php if ($social_url) : ?>
                      </a>
                      <?php endif; ?>
                    </div>
                    <?php endwhile; ?>
                  </div>
                  <?php endif; ?>
                </div>
                <!-- Fourth column -->
                <div class="col-xs-12 col-md-6 col-lg neighborhood-social-links-column hidden delay-3">
                  <div class="headline">
                    Shop
                  </div>
                  <!-- ACF repeater for social links -->
                  <?php if( have_rows('neighborhood_shop_links') ): ?>
                  <div class="social-links-wrap">
                    <?php while( have_rows('neighborhood_shop_links') ): the_row();
                      // vars
                      $title = get_sub_field('title');
                      $website_url = get_sub_field('website_url');
                      $social_url = get_sub_field('social_url');
                    ?>
                    <!-- link title -->
                    <div class="social-link-title">
                      <?php echo $title; ?>
                    </div>
                    <!-- link links -->
                    <div class="social-link-links">
                      <?php if ($website_url) : ?>
                      <a class="website-url" href="<?php echo $website_url['url']; ?>" target="_blank">
                      <?php endif; ?>
                        <span>&gt;</span> WEBSITE
                      <?php if ($website_url) : ?>
                      </a>
                      <?php endif; ?>
                      <?php if ($social_url) : ?>
                      <a class="social-url" href="<?php echo $social_url['url']; ?>" target="_blank">
                      <?php endif; ?>
                        SOCIAL
                      <?php if ($social_url) : ?>
                      </a>
                      <?php endif; ?>
                    </div>
                    <?php endwhile; ?>
                  </div>
                  <?php endif; ?>
                </div>
                <!-- for spacing -->
                <div class="col-lg-1"></div>
              </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
        </div>
      </div>
      </section>




      <!-- Fourth Section -->
      <section class="neighborhood-interactive-slider-section">
        <!-- <div class="container"> -->
          <div class="girls-walking-bg">
            <!-- Info block - custom width column -->
            <div class="custom-half-width-info-column info-block">
              <div class="headline hidden"><?php echo $neighborhood_slider_headline ?></div>
              <p class="white hidden delay-1"><?php echo $neighborhood_slider_desc ?></p>
            </div>
            <!-- Slider - custom width column -->
            <div class="custom-half-width-slider-column neighborhood-slider-wrap">
              <!-- Slick Slider 1 : BEGIN -->
              <?php if( have_rows('neighborhood_slider_1') ): ?>
              <div class="neighborhood-slider">
              <?php while( have_rows('neighborhood_slider_1') ): the_row();
                // vars
                $image   = get_sub_field('image');
                $title   = get_sub_field('title');
                $desc    = get_sub_field('desc');
                $maplink = get_sub_field('maplink');
                $link    = get_sub_field('link');
              ?>
                <!-- Slide -->
                <div>
                <?php if ( !empty($image) ) : ?>
                  <!-- <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"> -->
                  <!-- Default WP auto-gen image sizes -->
                  <img src="<?php echo $image['sizes']['large']; ?>" alt="<?php echo $image['alt']; ?>" />
                <?php endif; ?>
                  <div class="neighborhood-slider-card-info">
                    <div class="title"><?php echo $title ?></div>
                    <div class="desc"><?php echo $desc ?></div>
                    <div class="links">
                      <a class="google-map-link" href="<?php echo $maplink['url']; ?>" target="_blank"><span>&gt;</span> GOOGLE MAP</a>
                      <a class="visit-site" href="<?php echo $link['url']; ?>" target="_blank">VISIT SITE</a>
                    </div>
                  </div>
                </div>
              <?php endwhile; ?>
              </div>
              <?php endif; ?>
            </div>
            <!-- Slick Slider 1 : END -->

            <!-- Slider Mobile : BEGIN -->
            <div class="custom-mobile-slider-column">
              <!-- Slick Slider 1 : BEGIN -->
              <?php if( have_rows('neighborhood_slider_1') ): ?>
              <div class="neighborhood-slider-mobile">
              <?php while( have_rows('neighborhood_slider_1') ): the_row();
                // vars
                $image   = get_sub_field('image');
                $title   = get_sub_field('title');
                $desc    = get_sub_field('desc');
                $maplink = get_sub_field('maplink');
                $link    = get_sub_field('link');
              ?>
                <!-- Slide -->
                <div>
                <?php if ( !empty($image) ) : ?>
                  <!-- <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"> -->
                  <!-- Default WP auto-gen image sizes -->
                  <img src="<?php echo $image['sizes']['large']; ?>" alt="<?php echo $image['alt']; ?>" />
                <?php endif; ?>
                  <div class="neighborhood-slider-card-info">
                    <div class="title"><?php echo $title ?></div>
                    <div class="desc"><?php echo $desc ?></div>
                    <div class="links">
                      <a class="google-map-link" href="<?php echo $maplink['url']; ?>" target="_blank"><span>&gt;</span> GOOGLE MAP</a>
                      <a class="visit-site" href="<?php echo $link['url']; ?>" target="_blank">VISIT SITE</a>
                    </div>
                  </div>
                </div>
              <?php endwhile; ?>
              </div>
              <?php endif; ?>
            </div>
            <!-- Slider Mobile : END -->
          </div>
        <!-- </div> -->
      </section>




      <!-- Fifth Section -->
      <section class="check-available-units">
        <div class="container">
          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
            <!-- Info block -->
            <div class="col-xs-12 col-md-10">
              <div class="headline hidden">
                Check available units
              </div>
              <p class="hidden delay-1">Ready to move in? See what is available now.</p>
              <div class="info-block-actions hidden delay-2">
                <a href="/current-openings">
                  <div class="main-button">
                    LIVE HERE
                  </div>
                </a>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
          </div>
        </div>
      </section>



      <!-- Sixth Section -->
      <section class="neighborhood-small-gallery">
        <div class="neighborhood-footer-slider-mobile">
          <div>
            <img src="<?php bloginfo('stylesheet_directory'); ?>/images/neighborhood-small-gallery-thumb-1-compressed.jpg" alt="">
          </div>
          <div>
            <img src="<?php bloginfo('stylesheet_directory'); ?>/images/neighborhood-small-gallery-thumb-2-compressed.jpg" alt="">
          </div>
          <div>
            <img src="<?php bloginfo('stylesheet_directory'); ?>/images/neighborhood-small-gallery-thumb-3-compressed.jpg" alt="">
          </div>
          <div>
            <img src="<?php bloginfo('stylesheet_directory'); ?>/images/neighborhood-small-gallery-thumb-4-compressed.jpg" alt="">
          </div>
        </div>
        <div class="container neighborhood-footer-images">
          <img src="<?php bloginfo('stylesheet_directory'); ?>/images/neighborhood-small-gallery-thumb-1-compressed.jpg" alt="">
          <img src="<?php bloginfo('stylesheet_directory'); ?>/images/neighborhood-small-gallery-thumb-2-compressed.jpg" alt="">
          <img src="<?php bloginfo('stylesheet_directory'); ?>/images/neighborhood-small-gallery-thumb-3-compressed.jpg" alt="">
          <img src="<?php bloginfo('stylesheet_directory'); ?>/images/neighborhood-small-gallery-thumb-4-compressed.jpg" alt="">
        </div>
      </section>



      <!-- Fixed footer - apply for this unit -->
      <a class="fixed-footer-cta" href="/current-openings">
        <span>&gt;</span> VIEW UNITS
      </a>


      <!-- Footer wuz here!!! -->

    </div>

  </div>
</div>


<?php
get_footer();
