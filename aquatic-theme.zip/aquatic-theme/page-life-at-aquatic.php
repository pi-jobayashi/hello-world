<?php
/*
  Template name: Life at Aquatic
*/

// Advanced Custom Fields vars
// Header Section
$aquatic_header_headline        = get_field('aquatic_header_headline');
$aquatic_header_desc            = get_field('aquatic_header_desc');
// Video Overlay
$aquatic_vimeo_video_id         = get_field('aquatic_vimeo_video_id');
// Mission Section
$aquatic_mission_subline        = get_field('aquatic_mission_subline');
$aquatic_mission_headline       = get_field('aquatic_mission_headline');
$aquatic_leaf_a_subline         = get_field('aquatic_leaf_a_subline');
$aquatic_leaf_a_headline        = get_field('aquatic_leaf_a_headline');
$aquatic_leaf_a_desc            = get_field('aquatic_leaf_a_desc');
$aquatic_sticky_a_subline       = get_field('aquatic_sticky_a_subline');
$aquatic_sticky_a_headline      = get_field('aquatic_sticky_a_headline');
$aquatic_sticky_a_desc          = get_field('aquatic_sticky_a_desc');
$aquatic_coffee_a_subline       = get_field('aquatic_coffee_a_subline');
$aquatic_coffee_a_headline      = get_field('aquatic_coffee_a_headline');
$aquatic_coffee_a_desc          = get_field('aquatic_coffee_a_desc');
// Amenities Section
$aquatic_amenities_subline      = get_field('aquatic_amenities_subline');
$aquatic_amenities_headline     = get_field('aquatic_amenities_headline');
// Ready to Move Section
$aquatic_ready_to_move_headline    = get_field('aquatic_ready_to_move_headline');
$aquatic_ready_to_move_button_link = get_field('aquatic_ready_to_move_button_link');
// Social Section
$aquatic_social_subline         = get_field('aquatic_social_subline');
$aquatic_social_headline        = get_field('aquatic_social_headline');
$aquatic_social_gallery         = get_field('aquatic_social_gallery');
$aquatic_social_gallery_url     = get_field('aquatic_social_gallery_url');
// $aquatic_social_gallery_size    = 'medium';

get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="living">



    <!-- Header -->
    <header class="header aquatic-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
          <div class="col-md-1"></div>
          <!-- Info block -->
          <div class="col">
            <h1 class="headline white"><?php echo $aquatic_header_headline; ?></h1>
            <p><?php echo $aquatic_header_desc; ?></p>
            <div class="circle-play-button">
              <img src="<?php bloginfo('stylesheet_directory'); ?>/images/circle-play-button.svg" alt="Circle play button">
            </div>
          </div>
          <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
          <div class="col-md-1"></div>
        </div>
      </div>
    </header>


    <!-- Video Overlay -->
    <div class="video-overlay open">
      <div class="video-overlay-inner">
        <div class="fluid-width-video-wrapper" style="padding-top: 52.6563%;">
          <iframe src="https://player.vimeo.com/video/<?php echo $aquatic_vimeo_video_id; ?>" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen id="aquatic-living-video" data-ready="true"></iframe>
        </div>
      </div>
      <button class="video-overlay-close"></button>
    </div>


    <!-- Gallery Overlay -->
    <div id="amenities-gallery-overlay" class="slider-overlay open">
      <div class="slider-overlay-inner">
        <!-- Slick Slider Hero : BEGIN -->
        <?php if( have_rows('amenities_gallery_images') ): ?>
        <div class="amenities-gallery-slider">
        <?php while( have_rows('amenities_gallery_images') ): the_row();
          // vars
          $amenities_image  = get_sub_field('amenities_image');
        ?>
          <div>
            <img src="<?php echo $amenities_image['sizes']['large']; ?>" alt="<?php echo $image['alt']; ?>" />
          </div>
        <?php endwhile; ?>
        </div>
        <?php endif; ?>
        <!-- Slick Slider Hero : END -->
        <!-- Slick Slider Thumbs : BEGIN -->
        <?php if( have_rows('amenities_gallery_images') ): ?>
        <div class="amenities-gallery-slider-thumbs">
        <?php while( have_rows('amenities_gallery_images') ): the_row();
          // vars
          $amenities_image  = get_sub_field('amenities_image');
        ?>
          <div>
            <img src="<?php echo $amenities_image['sizes']['medium']; ?>" alt="<?php echo $image['alt']; ?>" />
          </div>
        <?php endwhile; ?>
        </div>
        <?php endif; ?>
        <!-- Slick Slider Thumbs : END -->
      </div>
      <button class="image-overlay-close"></button>
    </div>



    <!-- Main Content -->
    <div class="aquatic-content main">



      <!-- First Section -->
      <section class="our-mission">
        <div class="container">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
            <!-- Info block -->
            <div class="col info-block text-block">
              <div class="subline hidden"><?php echo $aquatic_mission_subline; ?></div>
              <h4 class="headline-italic hidden delay-1"><?php echo $aquatic_mission_headline; ?></h4>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
          </div>
          <!-- Triple A -->
          <div id="triple-a" class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
            <!-- Mobile Big A Gallery -->
            <div class="col-md-10 big-a-mobile-slider-wrap">
            <!-- <div class="big-a-mobile-slider hidden delay-2"> -->
              <div class="row">
                <div class="col">
                  <div class="big-a-mobile-slider">
                    <!-- Big A Slide 1 -->
                    <div class="big-a-letter">
                      <img src="<?php bloginfo('stylesheet_directory'); ?>/images/big-a-letters-leaves.jpg" alt="Big A Letter">
                      <div class="subline"><?php echo $aquatic_leaf_a_subline; ?></div>
                      <h2 class="headline"><?php echo $aquatic_leaf_a_headline; ?></h2>
                      <p>
                        <?php echo $aquatic_leaf_a_desc; ?>
                      </p>
                    </div>
                    <!-- Big A Slide 2 -->
                    <div class="big-a-letter">
                      <img src="<?php bloginfo('stylesheet_directory'); ?>/images/big-a-letters-stickynote.jpg" alt="Big A Letter">
                      <div class="subline"><?php echo $aquatic_sticky_a_subline; ?></div>
                      <h2 class="headline"><?php echo $aquatic_sticky_a_headline; ?></h2>
                      <p>
                        <?php echo $aquatic_sticky_a_desc; ?>
                      </p>
                    </div>
                    <!-- Big A Slide 3 -->
                    <div class="big-a-letter">
                      <img src="<?php bloginfo('stylesheet_directory'); ?>/images/big-a-letters-pourover.jpg" alt="Big A Letter">
                      <div class="subline"><?php echo $aquatic_coffee_a_subline; ?></div>
                      <h2 class="headline"><?php echo $aquatic_coffee_a_headline; ?></h2>
                      <p>
                        <?php echo $aquatic_coffee_a_desc; ?>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Triple A Desktop -->
            <div class="col-md-10 big-a-group">
              <!-- Big A Section -->
              <div class="col-4 big-a-letter hidden delay-2">
                <img src="<?php bloginfo('stylesheet_directory'); ?>/images/big-a-letters-leaves.jpg" alt="Big A Letter">
                <div class="subline"><?php echo $aquatic_leaf_a_subline; ?></div>
                <h2 class="headline"><?php echo $aquatic_leaf_a_headline; ?></h2>
                <p>
                  <?php echo $aquatic_leaf_a_desc; ?>
                </p>
              </div>
              <!-- Big A Section -->
              <div class="col-4 big-a-letter hidden delay-3">
                <img src="<?php bloginfo('stylesheet_directory'); ?>/images/big-a-letters-stickynote.jpg" alt="Big A Letter">
                <div class="subline"><?php echo $aquatic_sticky_a_subline; ?></div>
                <h2 class="headline"><?php echo $aquatic_sticky_a_headline; ?></h2>
                <p>
                  <?php echo $aquatic_sticky_a_desc; ?>
                </p>
              </div>
              <!-- Big A Section -->
              <div class="col-4 big-a-letter hidden delay-4">
                <img src="<?php bloginfo('stylesheet_directory'); ?>/images/big-a-letters-pourover.jpg" alt="Big A Letter">
                <div class="subline"><?php echo $aquatic_coffee_a_subline; ?></div>
                <h2 class="headline"><?php echo $aquatic_coffee_a_headline; ?></h2>
                <p>
                  <?php echo $aquatic_coffee_a_desc; ?>
                </p>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
          </div>
        </div>
      </section>



      <!-- Second Section -->
      <section id="amenities" class="amenities">
        <div class="container">
          <div class="row image-bg bikes-bg">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
            <!-- Info block -->
            <div class="col info-block">
              <div class="subline hidden"><?php echo $aquatic_amenities_subline; ?></div>
              <h2 class="headline hidden delay-1"><?php echo $aquatic_amenities_headline; ?></h2>

              <?php if( have_rows('amenities_gallery_images') ): ?>
                <div class="info-block-actions hidden">
                  <div id="amenities-gallery-button" class="main-button">
                    VIEW AMENITIES
                  </div>
                </div>
              <?php endif; ?>
              
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
          </div>
          <!-- Amenities gallery -->


          <!-- First row -->
          <div class="amenities-gallery">
            <!-- Square Thumb - Row 1 : BEGIN -->
            <?php if( have_rows('aquatic_amenities_thumbs_row_1') ): ?>
            <div class="row square-thumbs-amenities">
              <div class="col-md-1"></div>
              <div class="col">
                <div class="row">
                  <?php while( have_rows('aquatic_amenities_thumbs_row_1') ): the_row();
                		// vars
                		$image = get_sub_field('image');
                		$video = get_sub_field('video');
                		$text  = get_sub_field('text');
                		?>
                		<div class="col-6 col-sm-6 col-md-4 col-lg-4 no-gutters order-thumbs-on-mobile">
                      <!-- If image, -->
                      <?php if( $image ): ?>
                        <img class="hidden" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt'] ?>" />
                			<?php endif; ?>
                      <!-- If video, -->
                      <?php if( $video ): ?>
                        <video class="hidden" src="<?php echo $video['url']; ?>" autoplay loop muted preload playsinline></video>
                			<?php endif; ?>
                      <div class="amenity-thumb-text-label hidden">
                        <?php echo $text ?>
                      </div>
                		</div>
                	<?php endwhile; ?>
                </div>
              </div>
              <div class="col-md-1"></div>
            </div>
            <?php endif; ?>
            <!-- Square Thumb - Row 1 : END -->
            <!-- Square Thumb - Row 3 : BEGIN -->
            <?php if( have_rows('aquatic_amenities_thumbs_row_3') ): ?>
            <div class="row square-thumbs-amenities">
              <div class="col-md-1"></div>
              <div class="col">
                <div class="row">
                  <?php while( have_rows('aquatic_amenities_thumbs_row_3') ): the_row();
                		// vars
                		$image = get_sub_field('image');
                		$text  = get_sub_field('text');
                		?>
                    <div class="col-6 col-sm-6 col-md-3 col-lg-3 no-gutters">
                      <!-- If image, -->
                      <?php if( $image ): ?>
                      <img class="hidden" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt'] ?>" />
                			<?php endif; ?>
                        <div class="amenity-thumb-text-label small hidden">
                        <?php echo $text ?>
                      </div>
                		</div>
                	<?php endwhile; ?>
                </div>
              </div>
              <div class="col-md-1"></div>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </section>



      <!-- Third Section -->
      <section class="ready-to-move">
        <div class="container">
          <div class="row image-bg street-bg">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
            <!-- Info block -->
            <div class="col info-block">
              <h2 class="headline hidden"><?php echo $aquatic_ready_to_move_headline; ?></h2>

              <?php if ( !empty($aquatic_ready_to_move_button_link) ) : ?>
              <div class="info-block-actions">
                <a class="hidden delay-1" href="<?php echo $aquatic_ready_to_move_button_link['url']; ?>">
                  <div class="main-button">
                    <?php echo $aquatic_ready_to_move_button_link['title']; ?>
                  </div>
                </a>
              </div>
              <?php endif; ?>

            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
          </div>
        </div>
      </section>



      <!-- Fourth Section -->
      <section class="instagram">
        <div class="container">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
            <!-- Info block -->
            <div class="col-md-6 info-block text-block">
              <div class="subline hidden"><?php echo $aquatic_social_subline; ?></div>
              <h2 class="headline headline-social-link hidden delay-1"><a href="<?php echo $aquatic_social_gallery_url; ?>" target="_blank"><?php echo $aquatic_social_headline; ?></a></h2>
            </div>
            <!-- Sticky note -->
            <div class="col-md-4 instagram-gallery">
              <div class="row">
                <?php if( $aquatic_social_gallery ): ?>
                    <?php foreach( $aquatic_social_gallery as $image ): ?>
                      <div class="col-6 no-gutters hidden delay-2">
                        <a href="<?php echo $aquatic_social_gallery_url; ?>" target="_blank">
                          <img src="<?php echo $image['sizes']['medium']; ?>" alt="<?php echo $image['alt']; ?>" />
                        </a>
                      </div>
                    <?php endforeach; ?>
                <?php endif; ?>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1 info-block"></div>
          </div>
        </div>
      </section>



      <!-- Fixed footer - apply for this unit -->
      <a class="fixed-footer-cta-mobile" href="/current-openings">
        <span>&gt;</span> VIEW UNITS
      </a>



      <!-- Footer wuz here!!! -->

    </div>

  </div>
</div>


<?php
get_footer();
