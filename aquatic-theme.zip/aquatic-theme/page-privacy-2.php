<?php
/*
  Template name: Privacy Policy v2.0
*/

// Advanced Custom Fields vars
// Header
$privacy_header_subline           = get_field('privacy_header_subline');
$privacy_header_headline          = get_field('privacy_header_headline');
// Privacy Section
$privacy_content_subline          = get_field('privacy_content_subline');
$privacy_content_headline         = get_field('privacy_content_headline');
// Privacy Contact
$privacy_content_address          = get_field('privacy_content_address');
$privacy_content_phone_1          = get_field('privacy_content_phone_1');
$privacy_content_phone_2          = get_field('privacy_content_phone_2');
$privacy_content_email            = get_field('privacy_content_email');

get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="privacy">



    <!-- Header -->
    <header class="header privacy-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline"><?php echo $privacy_header_subline ?></div>
            <h1 class="headline"><?php echo $privacy_header_headline ?></h1>
          </div>
        </div>
      </div>
    </header>




    <!-- Main Content -->
    <div class="privacy-content main">



      <!-- First Section -->
      <section class="privacy-details">
        <div class="container">
          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Content -->
            <div class="col-lg-1 info-block remove-for-mobile"></div>
            <!-- Privacy Contact Content -->
            <div class="col-lg-5 info-block">
              <div class="max-tablet-width">
                <div class="subline"><?php echo $privacy_content_subline ?></div>
                <h2 class="headline"><?php echo $privacy_content_headline ?></h2>
                <!-- Privacy Content Section : BEGIN -->
                <?php if( have_rows('privacy_content_content') ): ?>
                <div class="privacy-content-wrap">
                  <?php while( have_rows('privacy_content_content') ) : the_row();
                    // vars
                    $title = get_sub_field('title');
                    $desc = get_sub_field('desc');
                  ?>
                  <h5 class="privacy_content_title">
                    <?php echo $title ?>
                  </h5>
                  <p>
                    <?php echo $desc ?>
                  </p>
                  <?php endwhile; ?>
                </div>
                <?php endif; ?>
                <!-- Privacy Content Section : END -->
                <div class="eho-logo">
                  <img src="<?php bloginfo('stylesheet_directory'); ?>/images/equal-opportunity-housing-logo.svg" alt="equal-opportunity-housing-logo">
                </div>
              </div>
            </div>
            <!-- Privacy Contact Column -->
            <div class="col-lg-3 info-block">
              <div class="privacy-contact-info">
                <div class="max-tablet-width">
                  <!-- Privacy Section Contact Info -->
                  <div class="address">
                    <a class="contact-address" href="https://www.google.com/maps/place/The+Aquatic/@37.867057,-122.298602,15z/data=!4m5!3m4!1s0x0:0xe0a46af2d808ce1!8m2!3d37.867057!4d-122.298602?hl=en-US" target="_blank">
                      <?php echo $privacy_content_address ?>
                    </a>
                  </div>
                  <div class="phone-numbers">
                    <div>T: <a href="tel:<?php echo $privacy_content_phone_1 ?>"><?php echo $privacy_content_phone_1 ?></a></div>
                    <div>T: <a href="tel:<?php echo $privacy_content_phone_2 ?>"><?php echo $privacy_content_phone_2 ?></a></div>
                  </div>
                  <div class="emails">
                    <div>Email:</div>
                    <div><a href="mailto:<?php echo $privacy_content_email ?>"><?php echo $privacy_content_email ?></a></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-1 info-block remove-for-mobile"></div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
          <!-- Second row -->
        </div>
      </section>


      <!-- Footer wuz here!!! -->


    </div>

  </div>
</div>


<?php
get_footer();
