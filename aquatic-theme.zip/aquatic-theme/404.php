<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Aquatic
 */

get_header();
?>

<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="error-404">



    <!-- Header -->
    <header class="header error-404-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline">THIS PAGE DOES NOT EXIST</div>
            <h1 class="headline">Let's Take You Home</h1>
						<div class="info-block-actions">
							<a href="/">
								<div class="main-button">
									BACK TO HOME
								</div>
							</a>
						</div>
          </div>
        </div>
      </div>
    </header>




    <!-- Main Content -->
    <div class="error-404-content main">

      <!-- First Section -->




      <!-- Second Section -->


      <!-- Footer wuz here!!! -->

    </div>

  </div>
</div>


<?php
get_footer();
