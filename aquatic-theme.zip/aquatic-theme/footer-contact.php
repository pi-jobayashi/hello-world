<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Aquatic
 */

?>

	<!-- Custom footer for the contact page -->
	<!-- omitted in contact-aquatic page template -->
	<!-- Nav overlay -->
	<div class="nav-overlay">
		<div class="nav-overlay-bg-life"></div>
		<div class="nav-overlay-bg-locations"></div>
		<div class="nav-overlay-bg-cares"></div>
		<div class="nav-overlay-bg-tenants"></div>
		<div class="nav-overlay-bg-contact"></div>
		<div class="container nav-overlay-wrap">
			<div id="nav-overlay-row1" class="row">
				<a class="nav-overlay-hover-item" href="/aquatic-living">
					<div class="nav-overlay-item">
						<h5>CRAFTED CULTURE</h5>
						<h3>Life at Aquatic</h3>
					</div>
				</a>
				<a class="nav-overlay-hover-item" href="/locations">
					<div class="nav-overlay-item">
						<h5>FIND YOUR HOME</h5>
						<h3>Our Locations</h3>
					</div>
				</a>
				<a class="nav-overlay-hover-item" href="/cares">
					<div class="nav-overlay-item">
						<h5>COMMUNITY LOVE</h5>
						<h3>Aquatic Cares</h3>
					</div>
				</a>
			</div>
			<div id="nav-overlay-row2"  class="row">
				<a class="nav-overlay-hover-item" href="/tenant-portal">
					<div class="nav-overlay-subitem">
						<p>Tenant Portal</p>
					</div>
				</a>
				<a class="nav-overlay-hover-item" href="/contact-aquatic">
					<div class="nav-overlay-subitem">
						<p>Contact Aquatic</p>
					</div>
				</a>
			</div>
		</div>
	</div>



</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
