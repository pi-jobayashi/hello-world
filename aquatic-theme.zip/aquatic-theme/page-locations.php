<?php
/*
  Template name: Locations
*/

// Advanced Custom Fields vars
// Header
$locations_header_subline       = get_field('locations_header_subline');
$locations_header_headline      = get_field('locations_header_headline');
// Fourth Street Section
$locations_fourth_badge         = get_field('locations_fourth_badge');
$locations_fourth_subline       = get_field('locations_fourth_subline');
$locations_fourth_headline      = get_field('locations_fourth_headline');
$locations_fourth_desc          = get_field('locations_fourth_desc');
$locations_fourth_button        = get_field('locations_fourth_button');
$locations_fourth_text_link     = get_field('locations_fourth_text_link');
// Shattuck Section
$locations_shattuck_badge       = get_field('locations_shattuck_badge');
$locations_shattuck_subline     = get_field('locations_shattuck_subline');
$locations_shattuck_headline    = get_field('locations_shattuck_headline');
$locations_shattuck_desc        = get_field('locations_shattuck_desc');
$locations_shattuck_button      = get_field('locations_shattuck_button');
$locations_shattuck_text_link   = get_field('locations_shattuck_text_link');
// Gilman Section
$locations_gilman_badge       = get_field('locations_gilman_badge');
$locations_gilman_subline     = get_field('locations_gilman_subline');
$locations_gilman_headline    = get_field('locations_gilman_headline');
$locations_gilman_desc        = get_field('locations_gilman_desc');
$locations_gilman_button      = get_field('locations_gilman_button');
$locations_gilman_text_link   = get_field('locations_gilman_text_link');


get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="locations">



    <!-- Header -->
    <header class="header locations-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline white"><?php echo $locations_header_subline ?></div>
            <h1 class="headline white"><?php echo $locations_header_headline ?></h1>
          </div>
        </div>
      </div>
    </header>



    <!-- Main Content -->
    <div class="locations-content main">



      <!-- First Section -->
      <section class="locations-section fourth-street">
        <div class="container negative-top-margin">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Location content here -->
            <div class="col-10 locations-details slidey-slide-uppy-up">
              <div class="row">
                <div class="col-md-6 info-block">
                  <div class="subline"><?php echo $locations_fourth_subline ?></div>
                  <h2 class="headline"><?php echo $locations_fourth_headline ?></h2>
                  <p class="">
                    <?php echo $locations_fourth_desc ?>
                  </p>
                  <div class="info-block-actions">
                    <!-- Button -->
                    <?php if ( !empty($locations_fourth_button) ) : ?>
                      <a class="" href="<?php echo $locations_fourth_button['url']; ?>">
                        <div class="main-button">
                          <?php echo $locations_fourth_button['title']; ?>
                        </div>
                      </a>
                      <?php endif; ?>
                    <!-- Text Link -->
                    <?php if ( !empty($locations_fourth_text_link) ) : ?>
                      <div class="text-link">
                        <a href="<?php echo $locations_fourth_text_link['url']; ?>">
                          <?php echo $locations_fourth_text_link['title']; ?>
                        </a>
                      </div>
                    <?php endif; ?>
                  </div>
                  <div class="locations-stamp stamp-fourth-street">
                    <?php if ( !empty($locations_fourth_badge) ) : ?>
                      <img src="<?php echo $locations_fourth_badge['url']; ?>" alt="<?php echo $locations_fourth_badge['alt']; ?>">
                    <?php endif;?>
                  </div>
                </div>
                <!-- Locations gallery -->
                <!-- <div class="col-md-6 locations-photo-gallery-wrap"> -->
                <div class="col-md-6 locations-fourth-street-slider-wrap locations-slider-global-wrap">
                  <div class="row">
                    <!-- Fourth Street Slider - Dynamic via ACF w/ Static Backup Img : BEGIN -->
                    <?php if( have_rows('locations_slider_0') ) { ?>
                    <div class="col locations-fourth-street-slider locations-slider-global">
                    <?php while( have_rows('locations_slider_0') ): the_row();
                      // vars
                      $image0 = get_sub_field('locations_slider_0_image');
                    ?>
                      <div>
                        <img src="<?php echo $image0['sizes']['large-square']; ?>" alt="<?php echo $image0['alt']; ?>">
                      </div>
                    <?php endwhile; ?>
                    </div>
                    <?php } else { ?>
                    <div class="col locations-photo no-gutters">
                      <img src="<?php bloginfo('stylesheet_directory'); ?>/images/locations-square-thumb-1-higherRes-compressed.jpg" alt="Locations photo">
                    </div>
                    <?php } ?>
                    <!-- Fourth Street Slider - Dynamic via ACF : END -->
                  </div>
                </div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
        </div>
      </section>



      <!-- Second Section -->
      <section class="locations-section shattuck">
        <div class="container">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Location content here -->
            <div class="col-10 locations-details">
              <div class="row">
                <!-- Shattuck Slider Wrap -->
                <div class="col-md-6 locations-shattuck-slider-wrap locations-slider-global-wrap order-class">
                  <div class="row">
                    <!-- Shattuck Slider - Dynamic via ACF w/ Static Backup Img : BEGIN -->
                    <?php if( have_rows('locations_slider_1') ) { ?>
                    <div class="col locations-shattuck-slider locations-slider-global">
                  	<?php while( have_rows('locations_slider_1') ): the_row();
                  		// vars
                  		$image1 = get_sub_field('locations_slider_1_image');
                  	?>
                  		<div>
                        <img src="<?php echo $image1['sizes']['large-square']; ?>" alt="<?php echo $image1['alt']; ?>">
                  		</div>
                  	<?php endwhile; ?>
                    </div>
                    <?php } else { ?>
                    <div class="col locations-photo no-gutters">
                      <img src="<?php bloginfo('stylesheet_directory'); ?>/images/locations-square-thumb-large-1-compressed.jpg" alt="Locations photo">
                    </div>
                    <?php } ?>
                    <!-- Shattuck Slider - Dynamic via ACF : END -->
                  </div>
                </div>
                <!-- Locations Content -->
                <div class="col-md-6 info-block slidey-slide-uppy-up order-class">
                  <div class="subline hidden"><?php echo $locations_shattuck_subline ?></div>
                  <h2 class="headline hidden delay-1"><?php echo $locations_shattuck_headline ?></h2>
                  <p class="hidden delay-2">
                    <?php echo $locations_shattuck_desc ?>
                  </p>
                  <div class="info-block-actions">
                    <!-- Button -->
                    <?php if ( !empty($locations_shattuck_button) ) : ?>
                    <a class="hidden delay-3" href="<?php echo $locations_shattuck_button['url']; ?>">
                      <div class="main-button">
                        <?php echo $locations_shattuck_button['title']; ?>
                      </div>
                    </a>
                    <?php else : ?>
                      <div class="hidden delay-3">
                        <div class="main-button disabled">AVAILABLE 2020</div>
                      </div>
                    <?php endif; ?>
                    <!-- Text Link -->
                    <?php if ( !empty( $locations_shattuck_text_link) ) : ?>
                      <div class="text-link hidden delay-4">
                        <a href="<?php echo $locations_shattuck_text_link['url']; ?>">
                          <?php echo $locations_shattuck_text_link['title']; ?>
                        </a>
                      </div>
                    <?php endif; ?>
                  </div>
                  <div class="locations-stamp stamp-shattuck hidden">
                    <?php if ( !empty($locations_shattuck_badge) ) : ?>
                      <img src="<?php echo $locations_shattuck_badge['url']; ?>" alt="<?php echo $locations_shattuck_badge['alt']; ?>">
                    <?php endif;?>
                  </div>
                </div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
        </div>
      </section>



      <!-- Third Section -->
      <section class="locations-section gilman">
        <div class="container">
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Location content here -->
            <div class="col-10 locations-details">
              <div class="row">
                <div class="col-md-6 info-block slidey-slide-uppy-up z-indexer-upper">
                  <div class="subline hidden"><?php echo $locations_gilman_subline ?></div>
                  <h2 class="headline hidden delay-1"><?php echo $locations_gilman_headline ?></h2>
                  <p class="hidden delay-2">
                    <?php echo $locations_gilman_desc ?>
                  </p>
                  <div class="info-block-actions">
                    <!-- Button -->
                    <?php if ( !empty($locations_gilman_button) ) : ?>
                    <a class="hidden delay-3" href="<?php echo $locations_gilman_button['url']; ?>">
                      <div class="main-button">
                        <?php echo $locations_gilman_button['title']; ?>
                      </div>
                    </a>
                    <?php else : ?>
                      <div class="hidden delay-3">
                        <div class="main-button disabled">AVAILABLE 2020</div>
                      </div>
                    <?php endif; ?>
                    <!-- Text Link -->
                    <?php if ( !empty( $locations_gilman_text_link) ) : ?>
                      <div class="text-link hidden delay-4">
                        <a href="<?php echo $locations_gilman_text_link['url']; ?>">
                          <?php echo $locations_gilman_text_link['title']; ?>
                        </a>
                      </div>
                    <?php endif; ?>
                  </div>
                  <div class="locations-stamp stamp-gilman hidden">
                    <?php if ( !empty($locations_gilman_badge) ) : ?>
                      <img src="<?php echo $locations_gilman_badge['url']; ?>" alt="<?php echo $locations_gilman_badge['alt']; ?>">
                    <?php endif;?>
                  </div>
                </div>
                <!-- Gilman Slider - Dynamic -->
                <div class="col-md-6 locations-gilman-slider-wrap locations-slider-global-wrap">
                  <div class="row">
                    <!-- Gilman Slider - Dynamic via ACF w/ Static Backup Img : BEGIN -->
                    <?php if( have_rows('locations_slider_2') ) : ?>
                    <div class="col locations-gilman-slider locations-slider-global">
                  	<?php while( have_rows('locations_slider_2') ): the_row();
                  		// vars
                  		$image2 = get_sub_field('locations_slider_2_image');
                  	?>
                  		<div>
                        <img src="<?php echo $image2['sizes']['large-square']; ?>" alt="<?php echo $image2['alt']; ?>">
                  		</div>
                  	<?php endwhile; ?>
                    </div>
                    <?php else : ?>
                    <div class="col locations-photo no-gutters">
                      <img src="<?php bloginfo('stylesheet_directory'); ?>/images/locations-square-thumb-large-2-compressed.jpg" alt="Locations photo">
                    </div>
                    <?php endif; ?>
                    <!-- Gilman Slider - Dynamic via ACF : END -->
                  </div>
                </div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
        </div>
      </section>



      <!-- Fixed footer - apply for this unit -->
      <a class="fixed-footer-cta-mobile" href="/current-openings">
        <span>&gt;</span> VIEW UNITS
      </a>



      <!-- Footer wuz here!!! -->

    </div>

  </div>
</div>


<?php
get_footer();
