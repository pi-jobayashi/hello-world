<?php
/*
  Template name: Unit
*/

// Advanced Custom Fields vars
// Header
$unit_header_subline           = get_field('unit_header_subline');
$unit_header_headline          = get_field('unit_header_headline');
// Image Overlay
$unit_overlay_image            = get_field('unit_overlay_image');
// Info Section
$unit_info_subline             = get_field('unit_info_subline');
$unit_info_desc                = get_field('unit_info_desc');
$unit_apply_button             = get_field('unit_apply_button');
// Details
$unit_detail_rent              = get_field('unit_detail_rent');
$unit_detail_bedbath           = get_field('unit_detail_bedbath');
$unit_detail_sqft              = get_field('unit_detail_sqft');
$unit_detail_available         = get_field('unit_detail_available');
// Matterport iframe URL
$unit_matterport_url           = get_field('unit_matterport_url');
// Lists
$unit_amenities_list           = get_field('unit_amenities_list');
$unit_neighborhood_list        = get_field('unit_neighborhood_list');
// Sub Details
$unit_detail_applicationfee    = get_field('unit_detail_applicationfee');
$unit_detail_deposit           = get_field('unit_detail_deposit');

get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="unit-page">



    <!-- Header -->
    <header class="header unit-page-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline"><?php echo $unit_header_subline ?></div>
            <h1 class="headline"><?php echo $unit_header_headline ?></h1>
          </div>
        </div>
      </div>
    </header>


    <!-- Image Overlay -->
    <div class="image-overlay open">
      <div class="image-overlay-inner">
        <?php if ( !empty($unit_overlay_image) ) : ?>
          <!-- <img src="<?php echo $unit_overlay_image['url']; ?>" alt="<?php echo $unit_overlay_image['alt']; ?>"> -->
          <img src="<?php echo $unit_overlay_image['sizes']['large']; ?>" alt="<?php echo $unit_overlay_image['alt']; ?>">
        <?php endif; ?>
      </div>
      <button class="image-overlay-close"></button>
    </div>

    <!-- Gallery Overlay -->
    <div id="unit-page-gallery-overlay" class="slider-overlay open">
      <div class="slider-overlay-inner">
        <!-- Slick Slider Hero : BEGIN -->
        <?php if( have_rows('unit_gallery_images') ): ?>
        <div class="unit-page-gallery-slider">
        <?php while( have_rows('unit_gallery_images') ): the_row();
          // vars
          $image  = get_sub_field('image');
        ?>
          <div>
            <!-- <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"> -->
            <!-- WP auto-gen image sizes -->
            <img src="<?php echo $image['sizes']['large']; ?>" alt="<?php echo $image['alt']; ?>" />
          </div>
        <?php endwhile; ?>
        </div>
        <?php endif; ?>
        <!-- Slick Slider Hero : END -->
        <!-- Slick Slider Thumbs : BEGIN -->
        <?php if( have_rows('unit_gallery_images') ): ?>
        <div class="unit-page-gallery-slider-thumbs">
        <?php while( have_rows('unit_gallery_images') ): the_row();
          // vars
          $image  = get_sub_field('image');
        ?>
          <div>
            <!-- <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"> -->
            <!-- WP auto-gen image sizes -->
            <img src="<?php echo $image['sizes']['medium']; ?>" alt="<?php echo $image['alt']; ?>" />
          </div>
        <?php endwhile; ?>
        </div>
        <?php endif; ?>
        <!-- Slick Slider Thumbs : END -->
      </div>
      <button class="image-overlay-close"></button>
    </div>



    <!-- Main Content -->
    <div class="unit-page-content main">


      <!-- First Section -->
      <section class="unit-page-section">
        <div class="container negative-top-margin">

          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>

            <!-- Info block -->
            <div class="col-md-10 info-block mobile-pad-fix">
              <!-- Main listing -->
              <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-5 info-block">
                  <div class="subline"><?php echo $unit_info_subline ?></div>
                  <h2 class="headline"><?php single_post_title(); ?></h2>
                  <p class="">
                    <?php echo $unit_info_desc ?>
                  </p>
                  <div class="info-block-actions apply-now-button">
                    <?php if ( !empty($unit_apply_button) ) : ?>
                    <a class="hidden delay-3" href="<?php echo $unit_apply_button['url']; ?>" target="_blank">
                      <div class="main-button">
                        <?php echo $unit_apply_button['title']; ?>
                      </div>
                    </a>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-5 floorplan-image-wrap">
                  <?php if ( !empty($unit_overlay_image) ) : ?>
                    <img src="<?php echo $unit_overlay_image['url']; ?>" alt="<?php echo $unit_overlay_image['alt']; ?>">
                  <?php endif; ?>
                  <div class="floorplan-lightbox-button-wrap">
                    <div class="floorplan-lightbox-button">
                      <img src="<?php bloginfo('stylesheet_directory'); ?>/images/floorplan-lightbox-button.png" alt="">
                    </div>
                  </div>
                </div>
                <div class="cold-md-1"></div>
              </div>
              <!-- Listing details -->
              <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 listing-details">
                  <div class="row">
                    <div class="col-6 col-md-3 listing-detail hidden">
                      <div class="subline">RENT</div>
                      <div class="headline-listing-detail"><?php echo $unit_detail_rent ?></div>
                    </div>
                    <div class="col-6 col-md-3 listing-detail hidden delay-1">
                      <div class="subline">BED/BATH</div>
                      <div class="headline-listing-detail"><?php echo $unit_detail_bedbath ?></div>
                    </div>
                    <div class="col-6 col-md-3 listing-detail hidden delay-2">
                      <div class="subline">SQ.FT</div>
                      <div class="headline-listing-detail"><?php echo $unit_detail_sqft ?></div>
                    </div>
                    <div class="col-6 col-md-3 listing-detail hidden delay-3">
                      <div class="subline">AVAILABLE</div>
                      <div class="headline-listing-detail"><?php echo $unit_detail_available ?></div>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
          </div>

        </div>
      </section>



      <!-- Second Section -->
      <section class="unit-page-full-width-gallery">
        <div class="container">
          <div class="row">
            <!-- Location content here -->
            <div class="col-2 no-gutters unit-page-full-width-gallery-left"></div>
            <div class="col-8 no-gutters unit-page-full-width-gallery-center"></div>
            <div class="col-2 no-gutters unit-page-full-width-gallery-right"></div>
          </div>
          <div class="info-block-actions">
            <div id="unit-page-gallery-button" class="main-button">
              VIEW GALLERY
            </div>
          </div>
        </div>
      </section>



      <!-- Third Section -->
      <section class="unit-page-section">
        <div class="container">

          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>

            <!-- Info block -->
            <div class="col-md-10 info-block details-section matterport-padding">

              <!-- Matterport -->
              <h4>Take a 3D Tour</h4>
              <div class="row matterport-wrap">
              <?php if ( $unit_matterport_url ) : ?>
                <iframe class="matterport" width='853' height='480' src='<?php echo $unit_matterport_url['url']; ?>' frameborder='0' allowfullscreen allow='vr'></iframe>
              <?php endif; ?>
              </div>

              <!-- Main listing -->
              <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-5 info-block">
                  <div class="subline hidden">MORE THAN A HOUSE</div>
                  <h2 class="headline hidden delay-2">Amenities</h2>
                  <div class="hidden delay-4">
                    <?php echo $unit_amenities_list ?>
                  </div>
                  <div class="info-block-actions">
                    <?php if ( !empty($unit_apply_button) ) : ?>
                    <a class="hidden" href="<?php echo $unit_apply_button['url']; ?>" target="_blank">
                      <div class="main-button">
                        <?php echo $unit_apply_button['title']; ?>
                      </div>
                    </a>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-5 info-block">
                  <div class="subline hidden delay-1">JOIN THE COMMUNITY</div>
                  <h2 class="headline hidden delay-3">Neighborhood</h2>
                  <div class="hidden delay-5">
                    <?php echo $unit_neighborhood_list ?>
                  </div>
                  <div class="info-block-actions neighborhood">
                    <div class="text-link hidden">
                      <a class="left-justified-underline" href="/neighborhood">DISCOVER MORE</a>
                    </div>
                  </div>
                </div>
                <div class="cold-md-1"></div>
              </div>
              <!-- Listing details -->
              <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                  <div class="row">
                    <div class="col-sm-12 col-md-4 col-lg-5 sub-details hidden">
                      <div class="subline">MORE THAN A BUILDING</div>
                      <div class="headline">Aquatic</div>
                      <p>Discover the culture behind Aquatic</p>
                      <div class="info-block-actions">
                        <div class="text-link">
                          <a class="left-justified-underline" href="/aquatic-living">LEARN MORE</a>
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-4 sub-details hidden delay-1">
                      <div class="subline">MEOW, BARK</div>
                      <div class="headline">Pets</div>
                      <p>Cats & Dogs are <span class="strike-through">allowed</span> loved</p>
                      <!-- <p>Cold blooded critters too</p>
                      <p>Please talk to us about ones that fly</p> -->
                    </div>
                    <div class="col-sm-12 col-md-4 col-lg-3 sub-details hidden delay-2">
                      <div class="subline">FINE PRINT</div>
                      <div class="headline terms">Terms</div>
                      <p><strong>Rent:</strong> <?php echo $unit_detail_rent ?></p>
                      <p><strong>Application Fee:</strong> <?php echo $unit_detail_applicationfee ?></p>
                      <p><strong>Security Deposit:</strong> <?php echo $unit_detail_deposit ?></p>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
              </div>
              <div class="row">
                <div class="col questions-cta hidden delay-3">
                  Questions? <a href="/contact-aquatic">Get in touch</a>
                </div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-md-1"></div>
          </div>

        </div>
      </section>


      <!-- Fixed footer - apply for this unit -->
      <?php if ( !empty($unit_apply_button) ) : ?>
      <a class="fixed-footer-cta" href="<?php echo $unit_apply_button['url']; ?>" target="_blank">
        <span>&gt;</span> APPLY FOR THIS UNIT
      </a>
      <?php endif; ?>


      <!-- Footer wuz here!!! -->

    </div>

  </div>
</div>


<?php
get_footer();
