<?php
/*
  Template name: Tenant Portal
*/

// Advanced Custom Fields vars
// Tenant Headline
$tenant_header_subline     = get_field('tenant_header_subline');
$tenant_header_headline    = get_field('tenant_header_headline');
// Module 1
$tenant_module_1_headline  = get_field('tenant_module_1_headline');
$tenant_module_1_desc      = get_field('tenant_module_1_desc');
$tenant_module_1_button    = get_field('tenant_module_1_button');
$tenant_module_1_text_link = get_field('tenant_module_1_text_link');
// Module 2
$tenant_module_2_headline  = get_field('tenant_module_2_headline');
$tenant_module_2_desc      = get_field('tenant_module_2_desc');
$tenant_module_2_button    = get_field('tenant_module_2_button');
$tenant_module_2_text_link = get_field('tenant_module_2_text_link');
// Module 3
$tenant_module_3_headline  = get_field('tenant_module_3_headline');
$tenant_module_3_desc      = get_field('tenant_module_3_desc');
$tenant_module_3_button    = get_field('tenant_module_3_button');
$tenant_module_3_text_link = get_field('tenant_module_3_text_link');
// Module 4
$tenant_module_4_headline  = get_field('tenant_module_4_headline');
// Staff Section
$tenant_staff_headline     = get_field('tenant_staff_headline');
$tenant_staff_desc         = get_field('tenant_staff_desc');

get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="tenants">



    <!-- Header -->
    <header class="header tenants-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline"><?php echo $tenant_header_subline ?></div>
            <h1 class="headline"><?php echo $tenant_header_headline ?></h1>
          </div>
        </div>
      </div>
    </header>




    <!-- Main Content -->
    <div class="tenants-content main">



      <!-- First Section -->
      <section class="tenants-services">
        <div class="container">
          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Info block -->
            <div class="col-10">
              <!-- Row 1 -->
              <div class="row">
                <div class="col-md-1 info-block"></div>
                <!-- Module 1 -->
                <div class="col-md-5 info-block text-block extra-top-padding">
                  <h4 class="headline"><?php echo $tenant_module_1_headline ?></h4>
                  <p class=""><?php echo $tenant_module_1_desc ?></p>
                  <div class="info-block-actions">
                    <?php if ( !empty($tenant_module_1_button) ) : ?>
                    <a class="" href="<?php echo $tenant_module_1_button['url']; ?>" target="<?php echo $tenant_module_1_button['target']; ?>">
                      <div class="main-button">
                        <?php echo $tenant_module_1_button['title']; ?>
                      </div>
                    </a>
                    <?php endif; ?>
                    <?php if ( !empty($tenant_module_1_text_link) ) : ?>
                      <div class="text-link">
                        <a href="<?php echo $tenant_module_1_text_link['url']; ?>" target="<?php echo $tenant_module_1_text_link['target']; ?>">
                          <?php echo $tenant_module_1_text_link['title']; ?>
                        </a>
                      </div>
                    <?php endif; ?>
                  </div>
                </div>
                <!-- Module 2 -->
                <div class="col-md-5 info-block text-block extra-top-padding">
                  <h4 class="headline"><?php echo $tenant_module_2_headline ?></h4>
                  <p class=""><?php echo $tenant_module_2_desc ?></p>
                  <div class="info-block-actions">
                    <?php if ( !empty($tenant_module_2_button) ) : ?>
                    <a class="" href="<?php echo $tenant_module_2_button['url']; ?>" target="<?php echo $tenant_module_2_button['target']; ?>">
                      <div class="main-button">
                        <?php echo $tenant_module_2_button['title']; ?>
                      </div>
                    </a>
                    <?php endif; ?>
                    <?php if ( !empty($tenant_module_2_text_link) ) : ?>
                      <div class="text-link">
                        <a href="<?php echo $tenant_module_2_text_link['url']; ?>" target="<?php echo $tenant_module_2_text_link['target']; ?>">
                          <?php echo $tenant_module_2_text_link['title']; ?>
                        </a>
                      </div>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-1 info-block"></div>
              </div>
              <!-- Row 2 -->
              <div class="row">
                <div class="col-1 info-block"></div>
                <!-- Module 3 -->
                <div class="col-md-5 info-block text-block">
                  <h4 class="headline hidden"><?php echo $tenant_module_3_headline ?></h4>
                  <p class="hidden delay-1"><?php echo $tenant_module_3_desc ?></p>
                  <div class="info-block-actions">
                    <?php if ( !empty($tenant_module_3_button) ) : ?>
                    <a class="hidden delay-2" href="<?php echo $tenant_module_3_button['url']; ?>" target="<?php echo $tenant_module_3_button['target']; ?>">
                      <div class="main-button">
                        <?php echo $tenant_module_3_button['title']; ?>
                      </div>
                    </a>
                    <?php endif; ?>
                    <?php if ( !empty($tenant_module_3_text_link) ) : ?>
                      <div class="text-link hidden delay-3">
                        <a href="<?php echo $tenant_module_3_text_link['url']; ?>" target="<?php echo $tenant_module_3_text_link['target']; ?>">
                          <?php echo $tenant_module_3_text_link['title']; ?>
                        </a>
                      </div>
                    <?php endif; ?>
                  </div>
                </div>
                <!-- Module 4 (Social Apps) -->
                <div class="col-md-5 info-block text-block">
                  <h4 class="headline hidden delay-1"><?php echo $tenant_module_4_headline ?></h4>
                  <div class="tenants-apps-wrap">
                    <div class="row">
                      <!-- Social App 1 : BEGIN -->
                      <?php if( have_rows('social_app_1') ): ?>
                    	<div class="col col-6 hidden delay-2">
                      	<?php while( have_rows('social_app_1') ): the_row();
                      		// vars
                      		$image   = get_sub_field('image');
                      		$title   = get_sub_field('title');
                      		$desc    = get_sub_field('desc');
                      		$link    = get_sub_field('text_link');
                      		$android = get_sub_field('text_link_android');
                      		$ios     = get_sub_field('text_link_ios');
                      	?>
                        <?php if ( !empty($image) ) : ?>
                				<img class="app-logo" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt'] ?>" />
                        <?php endif; ?>
                        <div class="app-name"><?php echo $title ?></div>
                        <div class="app-desc"><?php echo $desc ?></div>
                        <!-- Desktop -->
                        <?php if ( !empty($link) ) : ?>
                          <div class="text-link desktop">
                            <a href="<?php echo $link['url']; ?>" target="<?php echo $link['target']; ?>">
                              <?php echo $link['title']; ?>
                            </a>
                          </div>
                        <?php endif; ?>

                        <div class="tentant-social-link-wrap">
                          <!-- Google Play -->
                          <?php if ( !empty($android) ) : ?>
                            <div class="text-link android">
                              <a href="<?php echo $android['url']; ?>" target="<?php echo $android['target']; ?>">
                                <?php echo $android['title']; ?>
                              </a>
                            </div>
                          <?php endif; ?>
                          <!-- Apple Store -->
                          <?php if ( !empty($ios) ) : ?>
                            <div class="text-link ios">
                              <a href="<?php echo $ios['url']; ?>" target="<?php echo $ios['target']; ?>">
                                <?php echo $ios['title']; ?>
                              </a>
                            </div>
                          <?php endif; ?>
                        </div>

                      	<?php endwhile; ?>
                      </div>
                      <?php endif; ?>
                      <!-- Social App 1 : END -->
                      <!-- Social App 2 : BEGIN -->
                      <?php if( have_rows('social_app_2') ): ?>
                    	<div class="col col-6 hidden delay-3">
                      	<?php while( have_rows('social_app_2') ): the_row();
                      		// vars
                      		$image = get_sub_field('image');
                      		$title = get_sub_field('title');
                      		$desc = get_sub_field('desc');
                      		$link = get_sub_field('text_link');
                          $android = get_sub_field('text_link_android');
                      		$ios     = get_sub_field('text_link_ios');
                      	?>
                        <?php if ( !empty($image) ) : ?>
                				<img class="app-logo" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt'] ?>" />
                        <?php endif; ?>

                        <div class="app-name"><?php echo $title ?></div>
                        <div class="app-desc"><?php echo $desc ?></div>
                        <!-- Desktop -->
                        <?php if ( !empty($link) ) : ?>
                          <div class="text-link desktop">
                            <a href="<?php echo $link['url']; ?>" target="<?php echo $link['target']; ?>">
                              <?php echo $link['title']; ?>
                            </a>
                          </div>
                        <?php endif; ?>

                        <div class="tentant-social-link-wrap">
                          <!-- Google Play -->
                          <?php if ( !empty($android) ) : ?>
                            <div class="text-link android">
                              <a href="<?php echo $android['url']; ?>" target="<?php echo $android['target']; ?>">
                                <?php echo $android['title']; ?>
                              </a>
                            </div>
                          <?php endif; ?>
                          <!-- Apple Store -->
                          <?php if ( !empty($ios) ) : ?>
                            <div class="text-link ios">
                              <a href="<?php echo $ios['url']; ?>" target="<?php echo $ios['target']; ?>">
                                <?php echo $ios['title']; ?>
                              </a>
                            </div>
                          <?php endif; ?>
                        </div>

                      	<?php endwhile; ?>
                      </div>
                      <?php endif; ?>
                      <!-- Social App 2 : END -->
                    </div>
                  </div>
                </div>
                <div class="col-1 info-block"></div>
              </div>
            </div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
          <!-- Second row -->
        </div>
      </section>



      <!-- Second Section -->
      <section class="aquatic-staff">
        <div class="container">
          <!-- Staff title -->
          <div class="row section-heading-wrap">
            <div class="col-md-1"></div>
            <div class="col section-heading">
              <?php if( have_rows('tenants_staff_profile') ): ?>
              <h4 class="headline hidden"><?php echo $tenant_staff_headline ?></h4>
              <p class="hidden delay-1"><?php echo $tenant_staff_desc ?></p>
              <?php endif; ?>
            </div>
            <div class="col-md-1"></div>
          </div>
          <!-- First row -->
          <div class="staff-gallery">
            <!-- Row 1 -->
            <div class="row square-thumbs-staff-photos">
              <div class="col-md-1"></div>
              <div class="col-md-10 staff-thumbs">
                <div class="row">
                  <div class="col-md-1"></div>
                  <div class="col">

                      <!-- Staff Thumb : BEGIN -->
                      <?php if( have_rows('tenants_staff_profile') ): ?>

                      <div class="row">

                      	<?php while( have_rows('tenants_staff_profile') ) : the_row();
                      		// vars
                      		$image = get_sub_field('staff_image');
                      		$name = get_sub_field('staff_name');
                      		$title = get_sub_field('staff_title');
                      	?>
                        <div class="col-xs-12 col-md-4 staff-thumb hidden">

                        <?php if ( !empty($image) ) : ?>
                				<img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt'] ?>" />
                        <?php endif; ?>
                        <div class="staff-label-wrap">
                          <div class="staff-label-details">
                            <p class="staff-name"><?php echo $name ?></p>
                            <p class="staff-title"><?php echo $title ?></p>
                          </div>
                        </div>

                        </div>

                      	<?php endwhile; ?>

                      </div>

                      <?php endif; ?>
                      <!-- Staff Thumb : END -->

                  </div>
                  <div class="col-md-1"></div>
                </div>
              </div>
              <div class="col-md-1"></div>
            </div>
          </div>
        </div>
      </section>

      <!-- Footer wuz here!!! -->

    </div>

  </div>
</div>


<?php
get_footer();
