<?php
/*
  Template name: Appfolio Vacancy Feed
*/

// Advanced Custom Fields vars

get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="appfolio-vacancy-feed">



    <!-- Header -->
    <header class="header appfolio-vacancy-feed-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline">APPFOLIO VACANCY FEED</div>
            <h1 class="headline">Aquatic Living</h1>
          </div>
        </div>
      </div>
    </header>




    <!-- Main Content -->
    <div class="appfolio-vacancy-feed-content">



      <!-- First Section -->
      <section class="appfolio-vacancy-feed-details">
        <div class="container">
          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <!-- Content -->
            <div class="col-lg-1 info-block remove-for-mobile"></div>
            <!-- Privacy Contact Content -->
            <div class="col-lg-10 info-block">
              <div class="max-tablet-width">
                <div class="subline">CURRENT VACANCIES</div>
                <h2 class="headline">Aquatic Fourth Street</h2>
                <p>Scroll within the Appfolio area to see all listings</p>
                <!-- Vacancy Feed : BEGIN -->
								<!-- Vacancy Feed : END -->
              </div>
            </div>
            <div class="col-lg-1 info-block remove-for-mobile"></div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
          </div>
          <!-- Second row -->
        </div>
      </section>


      <!-- Footer wuz here!!! -->


    </div>

  </div>
</div>

<?php
get_sidebar();
get_footer();
