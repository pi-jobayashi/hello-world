<?php
/*
  Template name: Contact
*/

// Advanced Custom Fields vars
// Header
$contact_header_subline           = get_field('contact_header_subline');
$contact_header_headline          = get_field('contact_header_headline');
// Contact Section
$contact_section_subline          = get_field('contact_section_subline');
$contact_section_headline         = get_field('contact_section_headline');

$contact_section_mojo             = get_field('contact_section_mojo');

$contact_section_address          = get_field('contact_section_address');
$contact_section_phone_1          = get_field('contact_section_phone_1');
$contact_section_phone_2          = get_field('contact_section_phone_2');
$contact_section_email            = get_field('contact_section_email');
$contact_section_a_desc           = get_field('contact_section_a_desc');

get_header();
?>



<!-- Barba.js for page transitions -->
<div id="barba-wrapper">
  <div class="barba-container" data-namespace="contact">



    <!-- Header -->
    <header class="header contact-header">
      <div class="fullscreen-image-wrap"></div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="subline"><?php echo $contact_header_subline ?></div>
            <h1 class="headline"><?php echo $contact_header_headline ?></h1>
          </div>
        </div>
      </div>
    </header>




    <!-- Main Content -->
    <div class="contact-content main">



      <!-- First Section -->
      <section class="contact-details">
        <div class="container">
          <!-- First row -->
          <div class="row">
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
            <!-- Content -->
            <div class="col-md-1 info-block remove-for-mobile"></div>
            <div class="col-md-5 info-block">
              <div class="subline"><?php echo $contact_section_subline ?></div>
              <h2 class="headline"><?php echo $contact_section_headline ?></h2>
              <div class="info-block-actions mojo-button">
                <a href="<?php echo $contact_section_mojo['url'];?>" target="_blank">
                  <div class="main-button">
                    <?php echo $contact_section_mojo['title']; ?>
                  </div>
                </a>
              </div>
              <div class="contact-links">
                <a class="contact-address" href="https://www.google.com/maps/place/The+Aquatic/@37.867057,-122.298602,15z/data=!4m5!3m4!1s0x0:0xe0a46af2d808ce1!8m2!3d37.867057!4d-122.298602?hl=en-US" target="_blank">
                  <?php echo $contact_section_address ?>
                </a>
              </div>
              <div class="contact-links phone-numbers">
                <p>T: <a href="tel:<?php echo $contact_section_phone_1 ?>"><?php echo $contact_section_phone_1 ?></a></p>
                <p>T: <a href="tel:<?php echo $contact_section_phone_2 ?>"><?php echo $contact_section_phone_2 ?></a></p>
              </div>
              <div class="contact-links emails">
                <p>Email:</p>
                <p><a href="mailto:<?php echo $contact_section_email ?>"><?php echo $contact_section_email ?></a></p>
              </div>
              <div class="eho-logo">
                <img src="<?php bloginfo('stylesheet_directory'); ?>/images/equal-opportunity-housing-logo.svg" alt="equal-opportunity-housing-logo">
              </div>
            </div>
            <div class="col-md-3 info-block big-a-wrap">
              <div class="row">
                <div class="big-a-and-text order-class">
                  <img class="big-a-contacts" src="<?php bloginfo('stylesheet_directory'); ?>/images/big-a-letters-beertap-compressed.jpg" alt="">
                  <div class="image-comment">
                    <?php echo $contact_section_a_desc ?>
                  </div>
                </div>
                <!-- Social Icons : BEGIN -->
                <?php if( have_rows('contact_section_social_icon') ): ?>
                <div class="social-logos order-class">
                  <!-- For mobile only EHO logo -->
                  <div class="social-logo eho-for-mobile">
                    <img src="<?php bloginfo('stylesheet_directory'); ?>/images/equal-opportunity-housing-logo.svg" alt="equal-opportunity-housing-logo">
                  </div>
                  <?php while( have_rows('contact_section_social_icon') ) : the_row();
                    // vars
                    $image = get_sub_field('image');
                    $link = get_sub_field('link');
                  ?>
                  <div class="social-logo">
                    <?php if ( !empty($link) ) : ?>
                    <a href="<?php echo $link ?>" target="_blank">
                    <?php endif; ?>
                      <?php if ( !empty($image) ) : ?>
                      <img src="<?php echo $image['url'] ?>" alt="<?php echo $image['alt'] ?>">
                      <?php endif; ?>
                    <?php if ( !empty($link) ) : ?>
                    </a>
                    <?php endif; ?>
                  </div>
                  <?php endwhile; ?>
                </div>
                <?php endif; ?>
                <!-- Social Icons : END -->
              </div>
            </div>
            <div class="col-md-1 info-block remove-for-mobile"></div>
            <!-- Spacer, to retain responsive bootstrap styling w/ stencil bg -->
            <div class="col-1"></div>
          </div>
          <!-- Second row -->
        </div>
      </section>


      <!-- Fixed footer - apply for this unit -->
      <a class="fixed-footer-cta-mobile" href="/current-openings">
        <span>&gt;</span> VIEW UNITS
      </a>


      <!-- Footer wuz here!!! -->


    </div>

  </div>
</div>


<?php
get_footer();
